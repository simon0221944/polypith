# PolyPitch Frontend Deployment Guide

This guide covers deploying the PolyPitch React frontend to Hostinger static hosting.

## Prerequisites

1. Hostinger hosting account with file manager access
2. Domain configured to point to Hostinger
3. PolyPitch backend running on Replit
4. Supabase project configured for authentication

## Step 1: Environment Configuration

### 1.1 Create Production Environment File

Create `.env` in the frontend root with your production values:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_API_BASE_URL=https://your-replit-project.replit.app
VITE_ENV=production
```

### 1.2 Supabase Configuration

In your Supabase project dashboard:

1. Go to Authentication > Settings > Site URL
2. Add your Hostinger domain: `https://yourdomain.com`
3. Go to Authentication > Settings > Redirect URLs
4. Add these URLs:
   - `https://yourdomain.com/dashboard`
   - `https://yourdomain.com`

## Step 2: Build the Application

### 2.1 Install Dependencies

```bash
cd frontend
npm install
```

### 2.2 Build for Production

```bash
npm run build
```

This creates a `dist` folder with optimized static files.

### 2.3 Verify Build

```bash
npm run preview
```

Test the production build locally before deployment.

## Step 3: Deploy to Hostinger

### 3.1 Upload Files

1. **File Manager Method:**
   - Login to Hostinger control panel
   - Open File Manager
   - Navigate to `public_html` directory
   - Upload contents of `dist` folder (not the folder itself)

2. **FTP Method:**
   - Use FTP client (FileZilla, etc.)
   - Connect to your Hostinger FTP
   - Upload `dist` contents to `public_html`

### 3.2 Configure URL Routing

Create `.htaccess` file in `public_html`:

```apache
RewriteEngine On
RewriteBase /

# Handle Angular and React Router
RewriteRule ^index\.html$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]

# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>

# Set cache headers
<IfModule mod_expires.c>
    ExpiresActive on
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/ico "access plus 1 year"
    ExpiresByType image/icon "access plus 1 year"
    ExpiresByType text/ico "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
</IfModule>
```

## Step 4: SSL and Security

### 4.1 Enable SSL

1. In Hostinger control panel
2. Go to SSL section
3. Enable "Force HTTPS Redirect"
4. Verify SSL certificate is active

### 4.2 Security Headers

Add to `.htaccess`:

```apache
# Security headers
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"
Header always set Referrer-Policy "strict-origin-when-cross-origin"
Header always set Permissions-Policy "camera=(), microphone=(), geolocation=()"
```

## Step 5: Domain Configuration

### 5.1 DNS Settings

Ensure your domain points to Hostinger:

- **A Record**: `@` → Hostinger IP
- **CNAME**: `www` → your main domain
- **SSL**: Enabled

### 5.2 Backend CORS

Update your Replit backend CORS settings to include your domain:

```python
# In app.py
CORS(app, origins=["https://yourdomain.com", "https://www.yourdomain.com"], supports_credentials=True)
```

## Step 6: Testing

### 6.1 Functionality Tests

1. **Authentication:**
   - Email/password login
   - OAuth providers (Google, Facebook, Apple)
   - Registration flow

2. **Core Features:**
   - Dashboard access
   - Proposal generation
   - Proposal viewing
   - Subscription management

3. **Responsive Design:**
   - Mobile devices
   - Tablet devices
   - Desktop browsers

### 6.2 Performance Tests

1. **Page Speed:**
   - Use Google PageSpeed Insights
   - Target score: 90+ for mobile/desktop

2. **Loading Times:**
   - Initial page load < 3 seconds
   - Route transitions < 1 second

## Step 7: Monitoring and Maintenance

### 7.1 Analytics

Add Google Analytics or similar to track:
- User registrations
- Proposal generations
- Page performance
- User journey

### 7.2 Error Monitoring

Implement error tracking:
- Browser console errors
- API call failures
- Authentication issues

### 7.3 Updates

For future updates:

1. Make changes locally
2. Test thoroughly
3. Build production version
4. Upload new files to Hostinger
5. Clear browser cache
6. Test live site

## Troubleshooting

### Common Issues

1. **Blank Page:**
   - Check browser console for errors
   - Verify environment variables
   - Check `.htaccess` configuration

2. **Authentication Not Working:**
   - Verify Supabase redirect URLs
   - Check CORS settings
   - Confirm SSL is enabled

3. **API Calls Failing:**
   - Verify backend URL in environment
   - Check CORS configuration
   - Confirm backend is running

4. **Routing Issues:**
   - Verify `.htaccess` file exists
   - Check RewriteEngine is enabled
   - Confirm file permissions

### Support Resources

- Hostinger documentation
- Supabase documentation
- React Router documentation
- Vite deployment guide

## Performance Optimization

### 7.1 Asset Optimization

- Images: Use WebP format when possible
- Fonts: Preload critical fonts
- JavaScript: Code splitting enabled
- CSS: Purged unused styles

### 7.2 Caching Strategy

- Static assets: 1 year cache
- HTML: No cache (for updates)
- API responses: Browser cache
- Service worker: Offline support

This deployment setup provides a production-ready PolyPitch frontend with optimal performance, security, and user experience.