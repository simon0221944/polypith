# PolyPitch - AI-Powered Multilingual Sales Proposal Generator

## Overview

PolyPitch is a full-stack SaaS platform that automatically generates AI-powered international sales proposals and e-commerce product content, fully localized for multiple countries and languages. The system integrates subscription-based billing and provides a comprehensive REST API for proposal generation and user management.

## System Architecture

### Backend Architecture
- **Framework**: Flask (Python 3.11) with modular blueprint structure
- **API Design**: RESTful endpoints organized by functionality (auth, proposals, payments, calendar, expenses)
- **Database**: PostgreSQL (via Supabase) with SQLAlchemy ORM
- **Authentication**: JWT-based token authentication with role-based access control
- **AI Integration**: OpenAI GPT-4o for multilingual content generation, scheduling optimization, and expense analysis
- **Payment Processing**: Stripe integration for subscription billing

### Frontend Architecture
- **Technology**: React 18 with TypeScript, Vite build tool, Tailwind CSS
- **Authentication**: Supabase Auth with OAuth (Google, Facebook, Apple) + JWT backend integration
- **State Management**: React Context for auth and language, direct API calls for data
- **Internationalization**: Support for English, Spanish, and Italian
- **Design System**: Dark theme with orange primary color (#FFA500), responsive mobile-first design
- **Communication**: REST API integration with Flask backend
- **Deployment**: Static hosting on Hostinger separate from backend

## Key Components

### 1. Authentication System (`routes/auth.py`)
- User registration and login endpoints
- JWT token generation and validation
- Password hashing with Werkzeug security
- Email and password validation utilities

### 2. Proposal Generation (`routes/api.py`, `services/openai_service.py`)
- AI-powered proposal generation using OpenAI GPT-4o
- Multilingual content creation with cultural localization
- Quota management based on subscription tiers
- Proposal storage and retrieval

### 3. Subscription Management (`routes/stripe_routes.py`, `services/stripe_service.py`)
- Multiple subscription plans: Free, Basic (€9.99), Pro (€19.99), Enterprise (€49.99)
- Stripe Checkout integration with plan-based pricing
- Webhook handling with signature verification for secure payment events
- Automatic tier management and quota updates based on subscription changes
- Free plan activation without payment processing

### 4. Database Models (`models.py`)
- **User Model**: Authentication, subscription status, quota tracking
- **Proposal Model**: Generated content storage and metadata
- **Calendar Model**: User calendar settings and working hours
- **Appointment Model**: Scheduled appointments with conflict detection
- **Expense Model**: Business expense tracking with AI categorization
- **ExpenseCategory Model**: Custom expense categories and budgets
- **Subscription Management**: Tier-based quota system with automatic reset

### 5. Utility Services
- **Validators** (`utils/validators.py`): Input validation for emails, passwords, and requests
- **Auth Utils** (`utils/auth_utils.py`): JWT token management and authentication decorators
- **Database Service** (`services/supabase_service.py`): Database connectivity and user statistics

## Data Flow

1. **User Registration/Login**
   - Frontend sends credentials to `/api/register` or `/api/login`
   - Backend validates input and creates/authenticates user
   - JWT token returned for subsequent requests

2. **Proposal Generation**
   - Authenticated user sends proposal request to `/api/generate-proposal`
   - System checks user quota and subscription status
   - OpenAI API generates localized content based on target country/language
   - Proposal saved to database and returned to user
   - User quota updated

3. **Subscription Management**
   - User initiates subscription via `/stripe/create-checkout-session`
   - Stripe Checkout handles payment processing
   - Webhooks update user subscription status and quotas
   - Access levels enforced based on subscription tier

## External Dependencies

### Backend Environment Variables
- `OPENAI_API_KEY`: OpenAI API key for GPT-4o access
- `STRIPE_SECRET_KEY`: Stripe secret key for payment processing
- `STRIPE_PRICE_FREE`: Stripe Price ID for Free plan (€0/month)
- `STRIPE_PRICE_BASIC`: Stripe Price ID for Basic plan (€9.99/month)
- `STRIPE_PRICE_PRO`: Stripe Price ID for Pro plan (€19.99/month)
- `STRIPE_PRICE_ENTERPRISE`: Stripe Price ID for Enterprise plan (€49.99/month)
- `STRIPE_WEBHOOK_SECRET`: Stripe webhook endpoint secret for signature verification
- `DATABASE_URL`: PostgreSQL connection string (Replit managed)
- `SESSION_SECRET`: Flask session secret key

### Frontend Environment Variables
- `VITE_SUPABASE_URL`: Supabase project URL for authentication
- `VITE_SUPABASE_ANON_KEY`: Supabase anonymous public key
- `VITE_API_BASE_URL`: Backend API URL (Replit deployment URL)

### Third-Party Services
- **OpenAI API**: GPT-4o model for multilingual proposal generation
- **Supabase**: Managed PostgreSQL database with real-time capabilities
- **Stripe**: Payment processing and subscription management
- **Replit**: Backend hosting and deployment platform

### Python Dependencies
- Flask ecosystem (Flask, Flask-CORS, Flask-Login, Flask-SQLAlchemy)
- OpenAI Python SDK
- Supabase Python client
- Stripe Python library
- PostgreSQL adapter (psycopg2-binary)
- JWT handling (PyJWT)
- Gunicorn for production deployment

## Deployment Strategy

### Current Setup
- **Platform**: Replit with Python 3.11 runtime
- **Web Server**: Gunicorn with auto-scaling deployment target
- **Database**: Supabase managed PostgreSQL
- **Environment**: Nix-based environment with OpenSSL and PostgreSQL packages

### Deployment Configuration
- **Run Command**: `gunicorn --bind 0.0.0.0:5000 main:app`
- **Port**: 5000 with auto-reload for development
- **Scaling**: Replit autoscale deployment target
- **Environment**: Stable Nix channel (24_05)

### Production Considerations
- Frontend deployed separately on Hostinger (static hosting)
- Backend-only deployment on Replit
- Environment variables managed through Replit secrets
- Database migrations handled through SQLAlchemy

## Changelog

- June 24, 2025: Initial backend setup and API development
- June 24, 2025: Complete React TypeScript frontend created with Supabase auth, Stripe integration, and multilingual support
- June 25, 2025: Extended platform with AI-powered appointment calendar and expense management modules
  - Added Calendar system with AI scheduling optimization
  - Added Expense tracking with AI categorization and analysis
  - Integrated both modules with existing architecture
  - Updated frontend with new calendar and expense pages
- June 26, 2025: Implemented comprehensive Stripe subscription system
  - Added support for multiple subscription plans (Free, Basic, Pro, Enterprise)
  - Configured Stripe Price IDs for EUR-based pricing
  - Enhanced webhook handling with signature verification
  - Added automatic tier management and quota updates
- June 27, 2025: Fixed critical security issue
  - Removed hard-coded Stripe webhook secret from documentation files
  - Updated validation scripts to use environment variables only
  - Created security setup guide for proper webhook configuration
  - Backend code already properly uses environment variables for security
- June 27, 2025: Resolved all security vulnerabilities from static code analysis
  - Fixed hardcoded passwords in test_all_checkout_sessions.py and test_stripe_integration.py
  - Replaced hardcoded webhook secret in stripe_checkout_test_results.md with secure placeholder
  - Added proper environment variable handling with error checking in test files
  - All sensitive credentials now use environment variables (TEST_USER_PASSWORD, TEST_USER_EMAIL)
- June 27, 2025: Completed comprehensive modern UI and prepared Hostinger migration package
  - Built complete React frontend with professional orange/black theme
  - Created all functional pages: dashboard, proposals, calendar, expenses, subscriptions
  - Implemented real-time API integration with deployed backend
  - Enhanced login/register pages with glass-morphism design
  - Added responsive mobile-first design with modern sidebar navigation
  - Created complete Hostinger deployment package with verification system
  - Package includes backend (415KB total), frontend, configuration templates, and migration guides

## User Preferences

Preferred communication style: Simple, everyday language.