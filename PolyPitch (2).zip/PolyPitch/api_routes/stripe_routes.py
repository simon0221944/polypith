from flask import Blueprint, request, jsonify, current_app, redirect
from app import db
from models import User, SubscriptionPlan
from utils.auth_utils import token_required
import stripe
import os
import logging

bp = Blueprint('stripe', __name__, url_prefix='/stripe')

# Set Stripe API key
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')

@bp.route('/create-checkout-session', methods=['POST'])
@token_required
def create_checkout_session_route(current_user):
    """Create Stripe checkout session for subscription"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Accept both price_id and plan parameters
        price_id = data.get('price_id')
        plan = data.get('plan')
        
        # Use plan parameter if provided, otherwise use price_id
        plan_or_price = plan or price_id
        
        if not plan_or_price:
            return jsonify({'error': 'Plan or price_id is required'}), 400
        
        # Get domain for redirect URLs
        domain = os.environ.get('REPLIT_DEV_DOMAIN', 'localhost:5000')
        if os.environ.get('REPLIT_DEPLOYMENT'):
            domain = os.environ.get('REPLIT_DEV_DOMAIN')
        else:
            domains = os.environ.get('REPLIT_DOMAINS', '').split(',')
            if domains and domains[0]:
                domain = domains[0]
        
        # Import here to avoid circular import
        from services.stripe_service import create_checkout_session
        
        # Create checkout session
        session_url = create_checkout_session(
            plan_name_or_price_id=plan_or_price,
            customer_email=current_user.email,
            customer_id=current_user.stripe_customer_id,
            user_id=current_user.id
        )
        
        return jsonify({
            'success': True,
            'checkout_url': session_url,
            'plan': plan_or_price
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Checkout session creation error: {str(e)}")
        return jsonify({'error': 'Failed to create checkout session'}), 500

@bp.route('/webhook', methods=['POST'])
def stripe_webhook():
    """Handle Stripe webhook events"""
    try:
        payload = request.get_data()
        sig_header = request.headers.get('Stripe-Signature')
        
        webhook_secret = os.environ.get('STRIPE_WEBHOOK_SECRET')
        
        if not webhook_secret:
            current_app.logger.warning("Stripe webhook secret not configured")
            return jsonify({'error': 'Webhook not configured'}), 400
        
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, webhook_secret
            )
        except ValueError:
            current_app.logger.error("Invalid payload in webhook")
            return jsonify({'error': 'Invalid payload'}), 400
        except stripe.error.SignatureVerificationError:
            current_app.logger.error("Invalid signature in webhook")
            return jsonify({'error': 'Invalid signature'}), 400
        
        # Import here to avoid circular import
        from services.stripe_service import handle_webhook_event
        
        # Handle the event  
        result = handle_webhook_event(payload, sig_header, webhook_secret)
        
        if result:
            return jsonify({'success': True}), 200
        else:
            return jsonify({'error': 'Failed to process webhook'}), 500
            
    except Exception as e:
        current_app.logger.error(f"Webhook processing error: {str(e)}")
        return jsonify({'error': 'Webhook processing failed'}), 500

@bp.route('/subscription-plans', methods=['GET'])
def get_subscription_plans():
    """Get available subscription plans"""
    try:
        from services.stripe_service import get_available_plans
        
        available_plans = get_available_plans()
        
        plans = []
        for plan_name, plan_data in available_plans.items():
            plan_info = {
                'id': plan_name,
                'name': plan_name.title(),
                'price': plan_data['price'],
                'currency': plan_data['currency'],
                'interval': 'month',
                'proposal_quota': plan_data['proposal_quota'],
                'stripe_price_id': plan_data['stripe_price_id']
            }
            
            # Add plan-specific features
            if plan_name == 'free':
                plan_info['features'] = [
                    '3 AI proposals per month',
                    'Basic multilingual support',
                    'Standard templates',
                    'Community support'
                ]
            elif plan_name == 'basic':
                plan_info['features'] = [
                    '50 AI proposals per month',
                    'Full multilingual support',
                    'Professional templates',
                    'Email support',
                    'Calendar scheduling',
                    'Expense tracking'
                ]
            elif plan_name == 'pro':
                plan_info['features'] = [
                    '200 AI proposals per month',
                    'Advanced AI features',
                    'Premium templates',
                    'Priority support',
                    'Advanced calendar features',
                    'Detailed expense analytics',
                    'Export capabilities'
                ]
            elif plan_name == 'enterprise':
                plan_info['features'] = [
                    '1000 AI proposals per month',
                    'Custom AI training',
                    'Enterprise templates',
                    'Dedicated support',
                    'Team collaboration',
                    'Advanced integrations',
                    'Custom reporting',
                    'SSO authentication'
                ]
            
            plans.append(plan_info)
        
        # Sort plans by price
        plans.sort(key=lambda x: x['price'])
        
        return jsonify({
            'success': True,
            'plans': plans
        })
        
    except Exception as e:
        logging.error(f"Get subscription plans error: {str(e)}")
        return jsonify({'error': 'Failed to get subscription plans'}), 500

@bp.route('/portal', methods=['POST'])
@token_required
def create_portal_session(current_user):
    """Create Stripe customer portal session"""
    try:
        if not current_user.stripe_customer_id:
            return jsonify({'error': 'No active subscription found'}), 400
        
        domain = os.environ.get('REPLIT_DEV_DOMAIN', 'localhost:5000')
        if os.environ.get('REPLIT_DEPLOYMENT'):
            domain = os.environ.get('REPLIT_DEV_DOMAIN')
        else:
            domains = os.environ.get('REPLIT_DOMAINS', '').split(',')
            if domains and domains[0]:
                domain = domains[0]
        
        session = stripe.billing_portal.Session.create(
            customer=current_user.stripe_customer_id,
            return_url=f"https://{domain}/dashboard"
        )
        
        return jsonify({
            'success': True,
            'portal_url': session.url
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Portal session creation error: {str(e)}")
        return jsonify({'error': 'Failed to create portal session'}), 500
