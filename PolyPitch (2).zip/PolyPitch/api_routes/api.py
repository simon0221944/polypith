from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
from app import db
from models import User, Proposal
from services.openai_service import generate_multilingual_proposal
from utils.validators import validate_proposal_request
from utils.auth_utils import token_required
import logging

bp = Blueprint('api', __name__, url_prefix='/api')

@bp.route('/generate-proposal', methods=['POST'])
@token_required
def generate_proposal(current_user):
    """Generate AI-powered multilingual proposal"""
    try:
        data = request.get_json()
        
        # Validate input data
        validation_error = validate_proposal_request(data)
        if validation_error:
            return jsonify({'error': validation_error}), 400
        
        # Check user quota
        current_user.reset_quota_if_needed()
        if not current_user.can_generate_proposal():
            return jsonify({
                'error': 'Proposal quota exceeded. Please upgrade your plan.',
                'quota_used': current_user.proposals_used,
                'quota_limit': current_user.proposal_quota
            }), 429
        
        # Extract proposal parameters
        title = data.get('title')
        target_country = data.get('target_country')
        target_language = data.get('target_language')
        product_description = data.get('product_description')
        company_info = data.get('company_info', '')
        target_audience = data.get('target_audience', '')
        
        # Generate proposal using OpenAI
        generated_content = generate_multilingual_proposal(
            product_description=product_description,
            target_country=target_country,
            target_language=target_language,
            company_info=company_info,
            target_audience=target_audience
        )
        
        # Save proposal to database
        proposal = Proposal(
            user_id=current_user.id,
            title=title,
            target_country=target_country,
            target_language=target_language,
            product_description=product_description,
            company_info=company_info,
            target_audience=target_audience,
            generated_content=generated_content
        )
        
        db.session.add(proposal)
        current_user.use_proposal_quota()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'proposal_id': proposal.id,
            'generated_content': generated_content,
            'quota_remaining': current_user.proposal_quota - current_user.proposals_used
        }), 201
        
    except Exception as e:
        current_app.logger.error(f"Error generating proposal: {str(e)}")
        db.session.rollback()
        return jsonify({'error': 'Failed to generate proposal. Please try again.'}), 500

@bp.route('/proposals', methods=['GET'])
@token_required
def get_proposals(current_user):
    """Get user's proposals with pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        per_page = min(per_page, 50)  # Limit to 50 per page
        
        proposals = Proposal.query.filter_by(user_id=current_user.id)\
            .order_by(Proposal.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        proposals_data = []
        for proposal in proposals.items:
            proposals_data.append({
                'id': proposal.id,
                'title': proposal.title,
                'target_country': proposal.target_country,
                'target_language': proposal.target_language,
                'product_description': proposal.product_description[:200] + '...' if len(proposal.product_description) > 200 else proposal.product_description,
                'created_at': proposal.created_at.isoformat(),
                'updated_at': proposal.updated_at.isoformat()
            })
        
        return jsonify({
            'proposals': proposals_data,
            'pagination': {
                'page': proposals.page,
                'pages': proposals.pages,
                'per_page': proposals.per_page,
                'total': proposals.total,
                'has_next': proposals.has_next,
                'has_prev': proposals.has_prev
            }
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Error fetching proposals: {str(e)}")
        return jsonify({'error': 'Failed to fetch proposals'}), 500

@bp.route('/proposals/<int:proposal_id>', methods=['GET'])
@token_required
def get_proposal(current_user, proposal_id):
    """Get specific proposal by ID"""
    try:
        proposal = Proposal.query.filter_by(
            id=proposal_id, 
            user_id=current_user.id
        ).first()
        
        if not proposal:
            return jsonify({'error': 'Proposal not found'}), 404
        
        return jsonify({
            'id': proposal.id,
            'title': proposal.title,
            'target_country': proposal.target_country,
            'target_language': proposal.target_language,
            'product_description': proposal.product_description,
            'company_info': proposal.company_info,
            'target_audience': proposal.target_audience,
            'generated_content': proposal.generated_content,
            'created_at': proposal.created_at.isoformat(),
            'updated_at': proposal.updated_at.isoformat()
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Error fetching proposal {proposal_id}: {str(e)}")
        return jsonify({'error': 'Failed to fetch proposal'}), 500

@bp.route('/user/quota', methods=['GET'])
@token_required
def get_user_quota(current_user):
    """Get user's current quota information"""
    try:
        current_user.reset_quota_if_needed()
        
        return jsonify({
            'subscription_tier': current_user.subscription_tier,
            'subscription_status': current_user.subscription_status,
            'proposal_quota': current_user.proposal_quota,
            'proposals_used': current_user.proposals_used,
            'quota_remaining': current_user.proposal_quota - current_user.proposals_used,
            'quota_reset_date': current_user.quota_reset_date.isoformat()
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Error fetching user quota: {str(e)}")
        return jsonify({'error': 'Failed to fetch quota information'}), 500
