#!/usr/bin/env python3
"""
Test all Stripe checkout sessions for PolyPitch subscription plans
"""

import requests
import json
import os

BASE_URL = "http://localhost:5000"

def get_auth_token():
    """Get authentication token"""
    test_password = os.environ.get("TEST_USER_PASSWORD")
    if not test_password:
        print("❌ TEST_USER_PASSWORD environment variable is required")
        return None
    
    login_data = {
        "email": os.environ.get("TEST_USER_EMAIL", "test@example.com"),
        "password": test_password
    }
    
    response = requests.post(f"{BASE_URL}/api/login", json=login_data)
    if response.status_code == 200:
        return response.json().get('token')
    else:
        print(f"Failed to login: {response.status_code}")
        return None

def test_checkout_session(price_id, plan_name, token):
    """Test checkout session for a specific plan"""
    print(f"\n🧪 Testing {plan_name} Plan (Price ID: {price_id})")
    print("=" * 60)
    
    headers = {"Authorization": f"Bearer {token}"}
    checkout_data = {"price_id": price_id}
    
    response = requests.post(
        f"{BASE_URL}/stripe/create-checkout-session",
        json=checkout_data,
        headers=headers
    )
    
    if response.status_code == 200:
        data = response.json()
        if plan_name == "Free":
            print("✅ Free plan activated directly (no Stripe checkout needed)")
            print(f"   Success URL: {data.get('checkout_url', 'N/A')}")
        else:
            print("✅ Stripe checkout session created successfully")
            checkout_url = data.get('checkout_url', '')
            print(f"   Checkout URL: {checkout_url[:80]}...")
            print(f"   Full URL: {checkout_url}")
            print(f"   Plan: {data.get('plan', plan_name)}")
    else:
        print(f"❌ Failed to create checkout session")
        print(f"   Status Code: {response.status_code}")
        print(f"   Response: {response.text}")
    
    return response.status_code == 200

def main():
    print("🚀 PolyPitch Stripe Checkout Session Testing")
    print("Testing all subscription plans with provided Price IDs\n")
    
    # Test plans with exact Price IDs provided by user
    test_plans = [
        ("price_1RduWuL7qTQUkVTLZF0zYQdr", "Free"),
        ("price_1RduXlL7qTQUkVTL0Iv9WoI2", "Basic"),
        ("price_1Rbec7L7qTQUkVTL7G3EZV8G", "Pro"),
        ("price_1RbeeYL7qTQUkVTLAM8VLrg1", "Enterprise")
    ]
    
    # Get authentication token
    token = get_auth_token()
    if not token:
        print("❌ Could not obtain authentication token")
        return
    
    print("✅ Authentication successful")
    
    # Test each plan
    successful_tests = 0
    for price_id, plan_name in test_plans:
        success = test_checkout_session(price_id, plan_name, token)
        if success:
            successful_tests += 1
    
    # Summary
    print(f"\n{'='*60}")
    print(f"📊 Test Summary: {successful_tests}/{len(test_plans)} checkout sessions successful")
    
    if successful_tests == len(test_plans):
        print("🎉 All checkout sessions are working correctly!")
        print("\n📋 Next Steps:")
        print("1. Use Stripe test card: 4242 4242 4242 4242")
        print("2. Complete checkout for paid plans in Stripe dashboard")
        print("3. Verify webhook events are received")
        print("4. Check user subscription status updates")
        print("\n🔗 Visit the checkout URLs above to test the full payment flow")
    else:
        print("❌ Some checkout sessions failed. Check the configuration.")
    
    print(f"\n💡 Note: Free plan doesn't require Stripe checkout and activates immediately")

if __name__ == "__main__":
    main()