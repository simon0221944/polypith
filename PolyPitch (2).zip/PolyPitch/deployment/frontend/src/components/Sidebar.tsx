import { Link, useLocation } from 'react-router-dom'
import { 
  LayoutDashboard, 
  FileText, 
  Calendar, 
  Receipt, 
  CreditCard, 
  Plus,
  Globe,
  ChevronLeft,
  ChevronRight
} from 'lucide-react'
import { useState } from 'react'
import { useLanguage } from '../contexts/LanguageContext'

interface SidebarProps {
  isCollapsed: boolean
  onToggleCollapse: () => void
}

export default function Sidebar({ isCollapsed, onToggleCollapse }: SidebarProps) {
  const location = useLocation()
  const { t } = useLanguage()

  const isActive = (path: string) => location.pathname === path

  const navigationItems = [
    {
      name: t('nav.dashboard'),
      href: '/dashboard',
      icon: LayoutDashboard,
      active: isActive('/dashboard')
    },
    {
      name: t('nav.proposals'),
      href: '/proposals',
      icon: FileText,
      active: isActive('/proposals')
    },
    {
      name: t('calendar.title'),
      href: '/calendar',
      icon: Calendar,
      active: isActive('/calendar')
    },
    {
      name: t('expenses.title'),
      href: '/expenses',
      icon: Receipt,
      active: isActive('/expenses')
    },
    {
      name: t('nav.subscription'),
      href: '/subscription',
      icon: CreditCard,
      active: isActive('/subscription')
    }
  ]

  const quickActions = [
    {
      name: t('proposals.create'),
      href: '/create-proposal',
      icon: Plus,
      bgColor: 'bg-primary-500 hover:bg-primary-600'
    }
  ]

  return (
    <div className={`bg-dark-900 border-r border-dark-700 transition-all duration-300 ${
      isCollapsed ? 'w-16' : 'w-64'
    } flex flex-col h-full`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-dark-700">
        {!isCollapsed && (
          <Link to="/" className="flex items-center space-x-2">
            <Globe className="h-8 w-8 text-primary-500" />
            <span className="text-xl font-bold text-white">PolyPitch</span>
          </Link>
        )}
        {isCollapsed && (
          <Globe className="h-8 w-8 text-primary-500 mx-auto" />
        )}
        <button
          onClick={onToggleCollapse}
          className="p-1 rounded-lg hover:bg-dark-800 text-gray-400 hover:text-white transition-colors"
        >
          {isCollapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navigationItems.map((item) => {
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              to={item.href}
              className={`flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-colors ${
                item.active
                  ? 'bg-primary-500 text-white'
                  : 'text-gray-300 hover:bg-dark-800 hover:text-white'
              }`}
              title={isCollapsed ? item.name : ''}
            >
              <Icon size={20} className="flex-shrink-0" />
              {!isCollapsed && (
                <span className="text-sm font-medium">{item.name}</span>
              )}
            </Link>
          )
        })}
      </nav>

      {/* Quick Actions */}
      <div className="p-4 border-t border-dark-700">
        {quickActions.map((action) => {
          const Icon = action.icon
          return (
            <Link
              key={action.href}
              to={action.href}
              className={`flex items-center justify-center space-x-2 w-full px-3 py-2.5 rounded-lg text-white font-medium transition-colors ${action.bgColor}`}
              title={isCollapsed ? action.name : ''}
            >
              <Icon size={20} />
              {!isCollapsed && (
                <span className="text-sm">{action.name}</span>
              )}
            </Link>
          )
        })}
      </div>
    </div>
  )
}