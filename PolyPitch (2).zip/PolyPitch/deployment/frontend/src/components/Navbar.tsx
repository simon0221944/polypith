import { Link, useLocation } from 'react-router-dom'
import { Globe, Menu, X, LogOut, User, Settings } from 'lucide-react'
import { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { useLanguage } from '../contexts/LanguageContext'
import { Language } from '../types'

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const { user, logout } = useAuth()
  const { language, setLanguage, t } = useLanguage()
  const location = useLocation()

  const isActive = (path: string) => location.pathname === path

  const languages: { code: Language; name: string; flag: string }[] = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'it', name: 'Italiano', flag: '🇮🇹' }
  ]

  return (
    <nav className="bg-dark-900 border-b border-dark-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Globe className="h-8 w-8 text-primary-500" />
              <span className="text-xl font-bold text-white">PolyPitch</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link
              to="/"
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                isActive('/') 
                  ? 'text-primary-500 bg-dark-800' 
                  : 'text-gray-300 hover:text-white hover:bg-dark-800'
              }`}
            >
              {t('nav.home')}
            </Link>
            
            {user && (
              <>
                <Link
                  to="/dashboard"
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive('/dashboard') 
                      ? 'text-primary-500 bg-dark-800' 
                      : 'text-gray-300 hover:text-white hover:bg-dark-800'
                  }`}
                >
                  {t('nav.dashboard')}
                </Link>
                <Link
                  to="/proposals"
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive('/proposals') 
                      ? 'text-primary-500 bg-dark-800' 
                      : 'text-gray-300 hover:text-white hover:bg-dark-800'
                  }`}
                >
                  {t('nav.proposals')}
                </Link>
                <Link
                  to="/calendar"
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive('/calendar') 
                      ? 'text-primary-500 bg-dark-800' 
                      : 'text-gray-300 hover:text-white hover:bg-dark-800'
                  }`}
                >
                  {t('calendar.title')}
                </Link>
                <Link
                  to="/expenses"
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive('/expenses') 
                      ? 'text-primary-500 bg-dark-800' 
                      : 'text-gray-300 hover:text-white hover:bg-dark-800'
                  }`}
                >
                  {t('expenses.title')}
                </Link>
              </>
            )}
            
            <Link
              to="/pricing"
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                isActive('/pricing') 
                  ? 'text-primary-500 bg-dark-800' 
                  : 'text-gray-300 hover:text-white hover:bg-dark-800'
              }`}
            >
              {t('nav.pricing')}
            </Link>

            {/* Language Selector */}
            <div className="relative">
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="bg-dark-800 text-white border border-dark-600 rounded px-2 py-1 text-sm"
              >
                {languages.map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.flag} {lang.name}
                  </option>
                ))}
              </select>
            </div>

            {user ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2 text-gray-300 hover:text-white"
                >
                  <User className="h-5 w-5" />
                  <span className="text-sm">{user.username}</span>
                </button>
                
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-dark-800 rounded-md shadow-lg border border-dark-600 z-50">
                    <div className="py-1">
                      <Link
                        to="/subscription"
                        className="block px-4 py-2 text-sm text-gray-300 hover:bg-dark-700 hover:text-white"
                        onClick={() => setShowUserMenu(false)}
                      >
                        <Settings className="inline h-4 w-4 mr-2" />
                        {t('nav.subscription')}
                      </Link>
                      <button
                        onClick={() => {
                          logout()
                          setShowUserMenu(false)
                        }}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-dark-700 hover:text-white"
                      >
                        <LogOut className="inline h-4 w-4 mr-2" />
                        {t('nav.logout')}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <Link
                  to="/login"
                  className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
                >
                  {t('nav.login')}
                </Link>
                <Link
                  to="/register"
                  className="btn-primary text-sm"
                >
                  {t('nav.register')}
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-300 hover:text-white p-2"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-dark-800 border-t border-dark-700">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                isActive('/') 
                  ? 'text-primary-500 bg-dark-700' 
                  : 'text-gray-300 hover:text-white hover:bg-dark-700'
              }`}
              onClick={() => setIsOpen(false)}
            >
              {t('nav.home')}
            </Link>
            
            {user && (
              <>
                <Link
                  to="/dashboard"
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    isActive('/dashboard') 
                      ? 'text-primary-500 bg-dark-700' 
                      : 'text-gray-300 hover:text-white hover:bg-dark-700'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {t('nav.dashboard')}
                </Link>
                <Link
                  to="/proposals"
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    isActive('/proposals') 
                      ? 'text-primary-500 bg-dark-700' 
                      : 'text-gray-300 hover:text-white hover:bg-dark-700'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {t('nav.proposals')}
                </Link>
                <Link
                  to="/calendar"
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    isActive('/calendar') 
                      ? 'text-primary-500 bg-dark-700' 
                      : 'text-gray-300 hover:text-white hover:bg-dark-700'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {t('calendar.title')}
                </Link>
                <Link
                  to="/expenses"
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    isActive('/expenses') 
                      ? 'text-primary-500 bg-dark-700' 
                      : 'text-gray-300 hover:text-white hover:bg-dark-700'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {t('expenses.title')}
                </Link>
              </>
            )}
            
            <Link
              to="/pricing"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                isActive('/pricing') 
                  ? 'text-primary-500 bg-dark-700' 
                  : 'text-gray-300 hover:text-white hover:bg-dark-700'
              }`}
              onClick={() => setIsOpen(false)}
            >
              {t('nav.pricing')}
            </Link>

            {user ? (
              <div className="border-t border-dark-600 pt-2">
                <Link
                  to="/subscription"
                  className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-dark-700"
                  onClick={() => setIsOpen(false)}
                >
                  {t('nav.subscription')}
                </Link>
                <button
                  onClick={() => {
                    logout()
                    setIsOpen(false)
                  }}
                  className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-dark-700"
                >
                  {t('nav.logout')}
                </button>
              </div>
            ) : (
              <div className="border-t border-dark-600 pt-2 space-y-1">
                <Link
                  to="/login"
                  className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-dark-700"
                  onClick={() => setIsOpen(false)}
                >
                  {t('nav.login')}
                </Link>
                <Link
                  to="/register"
                  className="block px-3 py-2 rounded-md text-base font-medium bg-primary-500 text-white hover:bg-primary-600"
                  onClick={() => setIsOpen(false)}
                >
                  {t('nav.register')}
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  )
}