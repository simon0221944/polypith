export interface Appointment {
  id: number
  user_id: number
  calendar_id: number
  title: string
  description?: string
  start_time: string
  end_time: string
  status: 'scheduled' | 'completed' | 'cancelled'
  location?: string
  attendees?: string[]
  reminder_minutes?: number
  recurring: boolean
  recurring_pattern?: string
  recurring_end_date?: string
  created_at: string
  updated_at: string
}

export interface CalendarSettings {
  id: number
  user_id: number
  name: string
  timezone: string
  working_hours_start: string
  working_hours_end: string
  working_days: string
  break_duration: number
  created_at: string
  updated_at: string
}