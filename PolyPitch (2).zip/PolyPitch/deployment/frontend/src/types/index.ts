export interface User {
  id: number;
  username: string;
  email: string;
  subscription_tier: 'free' | 'basic' | 'premium';
  subscription_status: 'active' | 'canceled' | 'past_due';
  created_at: string;
}

export interface Proposal {
  id: number;
  title: string;
  target_country: string;
  target_language: string;
  product_description: string;
  company_info?: string;
  target_audience?: string;
  generated_content: string;
  created_at: string;
  updated_at: string;
}

export interface CreateProposalRequest {
  title: string;
  target_country: string;
  target_language: string;
  product_description: string;
  company_info?: string;
  target_audience?: string;
}

export interface SubscriptionPlan {
  id: number;
  name: string;
  stripe_price_id: string;
  proposal_quota: number;
  price: number;
  currency: string;
}

export interface UserQuota {
  subscription_tier: string;
  subscription_status: string;
  proposal_quota: number;
  proposals_used: number;
  quota_remaining: number;
  quota_reset_date: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  token: string;
  user: User;
}

export interface ApiError {
  error: string;
}

export type Language = 'en' | 'es' | 'it';

export interface TranslationKey {
  en: string;
  es: string;
  it: string;
}