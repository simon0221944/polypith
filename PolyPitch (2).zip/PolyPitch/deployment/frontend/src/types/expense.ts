export interface Expense {
  id: number
  user_id: number
  title: string
  description?: string
  amount: number
  currency: string
  category: string
  ai_suggested_category?: string
  expense_date: string
  receipt_url?: string
  payment_method?: string
  vendor?: string
  project?: string
  is_recurring: boolean
  recurring_frequency?: string
  tags?: string
  created_at: string
  updated_at: string
}

export interface ExpenseCategory {
  id: number
  user_id: number
  name: string
  description?: string
  color: string
  budget_limit?: number
  is_default: boolean
  created_at: string
}

export interface ExpenseSummary {
  total_amount: number
  total_count: number
  average_per_day: number
  top_category?: {
    name: string
    amount: number
  }
  monthly_breakdown?: {
    [key: string]: number
  }
}