import React, { createContext, useContext, useEffect, useState } from 'react'
import { User } from '../types'
import { authApi } from '../lib/api'
import { supabase } from '../lib/supabase'
import toast from 'react-hot-toast'

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (username: string, email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  signInWithGoogle: () => Promise<void>
  signInWithFacebook: () => Promise<void>
  signInWithApple: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check for existing session
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem('auth_token')
        if (token) {
          const { user: userData } = await authApi.getProfile()
          setUser(userData)
        }
      } catch (error) {
        localStorage.removeItem('auth_token')
      } finally {
        setLoading(false)
      }
    }

    checkAuth()

    // Listen for Supabase auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session) {
        // When Supabase OAuth succeeds, create account in backend
        try {
          const { user: supabaseUser } = session
          if (supabaseUser?.email) {
            // Try to register or login with backend
            try {
              const response = await authApi.login(supabaseUser.email, 'oauth_user')
              localStorage.setItem('auth_token', response.token)
              setUser(response.user)
              toast.success('Successfully signed in!')
            } catch (error) {
              // If login fails, try to register
              const response = await authApi.register(
                supabaseUser.user_metadata?.full_name || supabaseUser.email.split('@')[0],
                supabaseUser.email,
                'oauth_user'
              )
              localStorage.setItem('auth_token', response.token)
              setUser(response.user)
              toast.success('Account created successfully!')
            }
          }
        } catch (error) {
          toast.error('Authentication failed')
        }
      } else if (event === 'SIGNED_OUT') {
        localStorage.removeItem('auth_token')
        setUser(null)
      }
    })

    return () => subscription.unsubscribe()
  }, [])

  const login = async (email: string, password: string) => {
    try {
      const response = await authApi.login(email, password)
      localStorage.setItem('auth_token', response.token)
      setUser(response.user)
      toast.success('Successfully logged in!')
    } catch (error: any) {
      const message = error.response?.data?.error || 'Login failed'
      toast.error(message)
      throw error
    }
  }

  const register = async (username: string, email: string, password: string) => {
    try {
      const response = await authApi.register(username, email, password)
      localStorage.setItem('auth_token', response.token)
      setUser(response.user)
      toast.success('Account created successfully!')
    } catch (error: any) {
      const message = error.response?.data?.error || 'Registration failed'
      toast.error(message)
      throw error
    }
  }

  const logout = async () => {
    localStorage.removeItem('auth_token')
    setUser(null)
    await supabase.auth.signOut()
    toast.success('Logged out successfully')
  }

  const signInWithGoogle = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/dashboard`
        }
      })
      if (error) throw error
    } catch (error: any) {
      toast.error('Google sign-in failed')
      throw error
    }
  }

  const signInWithFacebook = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'facebook',
        options: {
          redirectTo: `${window.location.origin}/dashboard`
        }
      })
      if (error) throw error
    } catch (error: any) {
      toast.error('Facebook sign-in failed')
      throw error
    }
  }

  const signInWithApple = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'apple',
        options: {
          redirectTo: `${window.location.origin}/dashboard`
        }
      })
      if (error) throw error
    } catch (error: any) {
      toast.error('Apple sign-in failed')
      throw error
    }
  }

  const value = {
    user,
    loading,
    login,
    register,
    logout,
    signInWithGoogle,
    signInWithFacebook,
    signInWithApple
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}