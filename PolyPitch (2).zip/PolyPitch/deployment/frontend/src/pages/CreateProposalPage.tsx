import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Globe, FileText, Building, Users, Sparkles } from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'
import { proposalApi } from '../lib/api'
import { CreateProposalRequest } from '../types'
import toast from 'react-hot-toast'

export default function CreateProposalPage() {
  const { t } = useLanguage()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState<CreateProposalRequest>({
    title: '',
    target_country: '',
    target_language: '',
    product_description: '',
    company_info: '',
    target_audience: ''
  })

  const countries = [
    'United States', 'Canada', 'United Kingdom', 'Germany', 'France', 
    'Spain', 'Italy', 'Netherlands', 'Belgium', 'Switzerland', 
    'Austria', 'Sweden', 'Norway', 'Denmark', 'Finland', 
    'Japan', 'South Korea', 'China', 'Australia', 'New Zealand',
    'Brazil', 'Mexico', 'Argentina', 'India', 'Singapore'
  ]

  const languages = [
    'English', 'Spanish', 'French', 'German', 'Italian', 'Portuguese',
    'Dutch', 'Swedish', 'Norwegian', 'Danish', 'Finnish',
    'Japanese', 'Korean', 'Chinese (Simplified)', 'Chinese (Traditional)',
    'Hindi', 'Arabic'
  ]

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await proposalApi.create(formData)
      toast.success('Proposal generated successfully!')
      navigate('/proposals')
    } catch (error: any) {
      const message = error.response?.data?.error || 'Failed to generate proposal'
      toast.error(message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-dark-950 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            {t('proposals.create')}
          </h1>
          <p className="text-gray-400">
            Create AI-powered multilingual sales proposals tailored for your target market
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Information */}
          <div className="card">
            <div className="flex items-center mb-6">
              <FileText className="h-6 w-6 text-primary-500 mr-3" />
              <h2 className="text-xl font-semibold text-white">Basic Information</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-300 mb-2">
                  {t('proposals.form.title')} *
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  required
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="e.g., Software Solution for Enterprise Automation"
                  className="input-field w-full"
                />
              </div>

              <div>
                <label htmlFor="target_country" className="block text-sm font-medium text-gray-300 mb-2">
                  {t('proposals.form.targetCountry')} *
                </label>
                <select
                  id="target_country"
                  name="target_country"
                  required
                  value={formData.target_country}
                  onChange={handleChange}
                  className="input-field w-full"
                >
                  <option value="">Select a country</option>
                  {countries.map(country => (
                    <option key={country} value={country}>{country}</option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="target_language" className="block text-sm font-medium text-gray-300 mb-2">
                  {t('proposals.form.targetLanguage')} *
                </label>
                <select
                  id="target_language"
                  name="target_language"
                  required
                  value={formData.target_language}
                  onChange={handleChange}
                  className="input-field w-full"
                >
                  <option value="">Select a language</option>
                  {languages.map(language => (
                    <option key={language} value={language}>{language}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Product Details */}
          <div className="card">
            <div className="flex items-center mb-6">
              <Sparkles className="h-6 w-6 text-primary-500 mr-3" />
              <h2 className="text-xl font-semibold text-white">Product Details</h2>
            </div>

            <div>
              <label htmlFor="product_description" className="block text-sm font-medium text-gray-300 mb-2">
                {t('proposals.form.productDescription')} *
              </label>
              <textarea
                id="product_description"
                name="product_description"
                required
                rows={6}
                value={formData.product_description}
                onChange={handleChange}
                placeholder="Describe your product or service in detail. Include key features, benefits, and what makes it unique..."
                className="input-field w-full"
              />
              <p className="text-xs text-gray-500 mt-1">
                Provide a comprehensive description to generate the best proposal
              </p>
            </div>
          </div>

          {/* Additional Context */}
          <div className="card">
            <div className="flex items-center mb-6">
              <Building className="h-6 w-6 text-primary-500 mr-3" />
              <h2 className="text-xl font-semibold text-white">Additional Context</h2>
              <span className="ml-2 text-sm text-gray-500">(Optional)</span>
            </div>

            <div className="space-y-6">
              <div>
                <label htmlFor="company_info" className="block text-sm font-medium text-gray-300 mb-2">
                  {t('proposals.form.companyInfo')}
                </label>
                <textarea
                  id="company_info"
                  name="company_info"
                  rows={4}
                  value={formData.company_info}
                  onChange={handleChange}
                  placeholder="Tell us about your company - history, values, achievements, team size, etc."
                  className="input-field w-full"
                />
              </div>

              <div>
                <label htmlFor="target_audience" className="block text-sm font-medium text-gray-300 mb-2">
                  <Users className="inline h-4 w-4 mr-1" />
                  {t('proposals.form.targetAudience')}
                </label>
                <textarea
                  id="target_audience"
                  name="target_audience"
                  rows={3}
                  value={formData.target_audience}
                  onChange={handleChange}
                  placeholder="Describe your target audience - company size, industry, decision makers, pain points..."
                  className="input-field w-full"
                />
              </div>
            </div>
          </div>

          {/* AI Enhancement Notice */}
          <div className="bg-primary-500/10 border border-primary-500/20 rounded-lg p-4">
            <div className="flex items-start">
              <Sparkles className="h-5 w-5 text-primary-400 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-primary-300 mb-1">
                  AI-Powered Enhancement
                </h3>
                <p className="text-sm text-primary-200/80">
                  Our AI will analyze your input and generate a culturally-adapted proposal that includes:
                  executive summary, problem statement, solution details, benefits, pricing structure,
                  implementation timeline, and culturally-appropriate business etiquette for your target market.
                </p>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => navigate('/proposals')}
              className="btn-ghost"
            >
              {t('common.cancel')}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="btn-primary px-8 py-3 flex items-center"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  {t('proposals.form.generating')}
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  {t('proposals.form.generate')}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}