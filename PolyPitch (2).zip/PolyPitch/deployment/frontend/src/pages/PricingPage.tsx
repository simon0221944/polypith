import { useState, useEffect } from 'react'
import { Check, Sparkles, Zap, Crown } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { useLanguage } from '../contexts/LanguageContext'
import { subscriptionApi } from '../lib/api'
import { SubscriptionPlan } from '../types'
import toast from 'react-hot-toast'

export default function PricingPage() {
  const { t } = useLanguage()
  const { user } = useAuth()
  const [plans, setPlans] = useState<SubscriptionPlan[]>([])
  const [loading, setLoading] = useState(true)
  const [processingPlan, setProcessingPlan] = useState<string | null>(null)

  useEffect(() => {
    fetchPlans()
  }, [])

  const fetchPlans = async () => {
    try {
      const data = await subscriptionApi.getPlans()
      setPlans(data.plans)
    } catch (error) {
      console.error('Failed to fetch plans:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubscribe = async (priceId: string) => {
    if (!user) {
      toast.error('Please login to subscribe')
      return
    }

    setProcessingPlan(priceId)
    try {
      const response = await subscriptionApi.createCheckoutSession(priceId)
      window.location.href = response.checkout_url
    } catch (error: any) {
      const message = error.response?.data?.error || 'Failed to create checkout session'
      toast.error(message)
    } finally {
      setProcessingPlan(null)
    }
  }

  const defaultPlans = [
    {
      id: 'free',
      name: 'Free',
      price: 0,
      currency: 'USD',
      proposal_quota: 3,
      stripe_price_id: '',
      features: [
        '3 proposals per month',
        'Basic AI generation',
        '17+ languages',
        'Email support'
      ],
      icon: Sparkles,
      popular: false
    },
    {
      id: 'basic',
      name: 'Basic',
      price: 29,
      currency: 'USD',
      proposal_quota: 50,
      stripe_price_id: 'price_basic',
      features: [
        '50 proposals per month',
        'Advanced AI features',
        'All languages',
        'Priority support',
        'Export to PDF'
      ],
      icon: Zap,
      popular: true
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 79,
      currency: 'USD',
      proposal_quota: 9999,
      stripe_price_id: 'price_premium',
      features: [
        'Unlimited proposals',
        'Premium AI models',
        'Custom templates',
        'API access',
        'White-label options'
      ],
      icon: Crown,
      popular: false
    }
  ]

  const displayPlans = plans.length > 0 ? plans : defaultPlans

  if (loading) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-dark-950 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            {t('pricing.title')}
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            {t('pricing.subtitle')}
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {displayPlans.map((plan, index) => {
            const Icon = plan.icon || Sparkles
            const isPopular = plan.popular || (plan.name.toLowerCase() === 'basic')
            const isFree = plan.price === 0
            const isProcessing = processingPlan === plan.stripe_price_id

            return (
              <div
                key={plan.id || index}
                className={`card relative ${
                  isPopular 
                    ? 'border-primary-500 ring-2 ring-primary-500/20' 
                    : 'border-dark-700'
                } ${isPopular ? 'scale-105' : ''} transition-all duration-300`}
              >
                {isPopular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-primary-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                      {t('pricing.mostPopular')}
                    </div>
                  </div>
                )}

                <div className="text-center">
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-lg mb-6 ${
                    isPopular ? 'bg-primary-500/20' : 'bg-dark-800'
                  }`}>
                    <Icon className={`h-8 w-8 ${
                      isPopular ? 'text-primary-400' : 'text-gray-400'
                    }`} />
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-2">
                    {plan.name}
                  </h3>

                  <div className="mb-6">
                    <span className="text-4xl font-bold text-white">
                      ${plan.price}
                    </span>
                    <span className="text-gray-400 ml-1">/month</span>
                  </div>

                  <ul className="space-y-4 mb-8">
                    {(plan.features || []).map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <button
                    onClick={() => isFree ? null : handleSubscribe(plan.stripe_price_id)}
                    disabled={isFree || isProcessing}
                    className={`w-full py-3 px-6 rounded-lg font-medium transition-colors ${
                      isPopular
                        ? 'bg-primary-500 hover:bg-primary-600 text-white'
                        : isFree
                        ? 'bg-dark-700 text-gray-400 cursor-not-allowed'
                        : 'bg-dark-800 hover:bg-dark-700 text-white border border-dark-600'
                    }`}
                  >
                    {isProcessing ? (
                      <div className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Processing...
                      </div>
                    ) : isFree ? (
                      'Current Plan'
                    ) : plan.name === 'Premium' ? (
                      t('pricing.contactSales')
                    ) : (
                      t('pricing.subscribe')
                    )}
                  </button>
                </div>
              </div>
            )
          })}
        </div>

        {/* FAQ Section */}
        <div className="mt-24">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Frequently Asked Questions
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <div className="card">
              <h3 className="text-lg font-semibold text-white mb-3">
                How does the AI proposal generation work?
              </h3>
              <p className="text-gray-400">
                Our AI analyzes your product description, target market, and cultural context to generate 
                professionally structured sales proposals that are culturally adapted for your specific market.
              </p>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold text-white mb-3">
                What languages are supported?
              </h3>
              <p className="text-gray-400">
                We support 17+ languages including English, Spanish, French, German, Italian, Portuguese, 
                Dutch, Japanese, Korean, Chinese, Hindi, Arabic, and many more.
              </p>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold text-white mb-3">
                Can I cancel my subscription anytime?
              </h3>
              <p className="text-gray-400">
                Yes, you can cancel your subscription at any time through your account settings. 
                You'll continue to have access until the end of your billing period.
              </p>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold text-white mb-3">
                Do you offer refunds?
              </h3>
              <p className="text-gray-400">
                We offer a 14-day money-back guarantee for all paid plans. If you're not satisfied, 
                contact our support team for a full refund.
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-24">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to Transform Your Global Sales?
          </h2>
          <p className="text-xl text-gray-400 mb-8 max-w-3xl mx-auto">
            Join thousands of businesses using PolyPitch to create winning proposals in any language.
          </p>
          {!user && (
            <div className="space-y-4">
              <a href="/register" className="btn-primary text-lg px-8 py-3 inline-block">
                Start Free Trial
              </a>
              <p className="text-sm text-gray-500">
                No credit card required • 3 free proposals
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}