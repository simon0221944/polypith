import { useEffect, useState } from 'react'
import { DollarSign, Plus, TrendingUp, TrendingDown, Filter, Download, Calendar, Tag, Search } from 'lucide-react'
import { expenseApi } from '../lib/api'
import { Expense, ExpenseCategory, ExpenseSummary } from '../types/expense'
import { formatCurrency, formatDate } from '../lib/utils'
import Card from '../components/ui/Card'
import toast from 'react-hot-toast'

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [categories, setCategories] = useState<ExpenseCategory[]>([])
  const [summary, setSummary] = useState<ExpenseSummary | null>(null)
  const [loading, setLoading] = useState(true)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState('')
  const [filterMonth, setFilterMonth] = useState(new Date().getMonth() + 1)
  const [filterYear, setFilterYear] = useState(new Date().getFullYear())
  const [newExpense, setNewExpense] = useState({
    title: '',
    description: '',
    amount: '',
    category: '',
    expense_date: new Date().toISOString().split('T')[0],
    payment_method: '',
    vendor: '',
    project: '',
    tags: ''
  })

  useEffect(() => {
    fetchData()
  }, [filterMonth, filterYear])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [expensesData, categoriesData, summaryData] = await Promise.all([
        expenseApi.getExpenses({ month: filterMonth, year: filterYear }),
        expenseApi.getCategories(),
        expenseApi.getSummary(filterMonth, filterYear)
      ])
      
      setExpenses(expensesData.expenses || [])
      setCategories(categoriesData.categories || [])
      setSummary(summaryData)
    } catch (error) {
      toast.error('Failed to load expenses data')
    } finally {
      setLoading(false)
    }
  }

  const handleCreateExpense = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await expenseApi.createExpense({
        ...newExpense,
        amount: parseFloat(newExpense.amount),
        tags: newExpense.tags.split(',').map(tag => tag.trim()).filter(Boolean)
      })
      
      toast.success('Expense created successfully!')
      setShowCreateForm(false)
      setNewExpense({
        title: '',
        description: '',
        amount: '',
        category: '',
        expense_date: new Date().toISOString().split('T')[0],
        payment_method: '',
        vendor: '',
        project: '',
        tags: ''
      })
      fetchData()
    } catch (error) {
      toast.error('Failed to create expense')
    }
  }

  const handleExport = async () => {
    try {
      const startDate = new Date(filterYear, filterMonth - 1, 1).toISOString().split('T')[0]
      const endDate = new Date(filterYear, filterMonth, 0).toISOString().split('T')[0]
      
      const data = await expenseApi.exportExpenses(startDate, endDate)
      
      // Create and download CSV
      const blob = new Blob([data.csv_data], { type: 'text/csv' })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `expenses-${filterYear}-${filterMonth.toString().padStart(2, '0')}.csv`
      link.click()
      window.URL.revokeObjectURL(url)
      
      toast.success('Expenses exported successfully!')
    } catch (error) {
      toast.error('Failed to export expenses')
    }
  }

  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = expense.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expense.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expense.vendor?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = !filterCategory || expense.category === filterCategory
    
    return matchesSearch && matchesCategory
  })

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ]

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="animate-pulse">
          <div className="h-8 bg-dark-800 rounded w-64 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-dark-800 rounded-xl h-32"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-500/10 to-green-600/10 border border-green-500/20 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-gradient-to-r from-green-500 to-green-600 rounded-xl">
              <DollarSign className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Expense Tracking</h1>
              <p className="text-gray-400">Monitor and manage your business expenses</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={handleExport}
              className="bg-dark-800 hover:bg-dark-700 text-white px-4 py-3 rounded-xl font-semibold transition-all duration-300 flex items-center border border-dark-600"
            >
              <Download className="h-5 w-5 mr-2" />
              Export
            </button>
            <button
              onClick={() => setShowCreateForm(true)}
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-green-500/25 flex items-center"
            >
              <Plus className="h-5 w-5 mr-2" />
              Add Expense
            </button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      {summary && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="hover:border-green-500/20 transition-all duration-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Total Expenses</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {formatCurrency(summary.total_amount)}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  {summary.total_count} transactions
                </p>
              </div>
              <div className="p-3 bg-green-500/10 rounded-lg">
                <DollarSign className="h-6 w-6 text-green-500" />
              </div>
            </div>
          </Card>

          <Card className="hover:border-blue-500/20 transition-all duration-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Average/Day</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {formatCurrency(summary.average_per_day)}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  This month
                </p>
              </div>
              <div className="p-3 bg-blue-500/10 rounded-lg">
                <TrendingUp className="h-6 w-6 text-blue-500" />
              </div>
            </div>
          </Card>

          <Card className="hover:border-purple-500/20 transition-all duration-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Top Category</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {summary.top_category?.name || 'N/A'}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  {summary.top_category ? formatCurrency(summary.top_category.amount) : ''}
                </p>
              </div>
              <div className="p-3 bg-purple-500/10 rounded-lg">
                <Tag className="h-6 w-6 text-purple-500" />
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search expenses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 pl-10 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
            />
          </div>

          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
          >
            <option value="">All Categories</option>
            {categories.map(category => (
              <option key={category.id} value={category.name}>{category.name}</option>
            ))}
          </select>

          <select
            value={filterMonth}
            onChange={(e) => setFilterMonth(parseInt(e.target.value))}
            className="bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
          >
            {months.map((month, index) => (
              <option key={index} value={index + 1}>{month}</option>
            ))}
          </select>

          <select
            value={filterYear}
            onChange={(e) => setFilterYear(parseInt(e.target.value))}
            className="bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
          >
            {[2024, 2025, 2026].map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>

          <button
            onClick={() => {
              setSearchTerm('')
              setFilterCategory('')
            }}
            className="bg-dark-800/50 border border-dark-600/50 text-gray-400 hover:text-white rounded-lg px-4 py-3 transition-colors duration-300"
          >
            Clear
          </button>
        </div>
      </Card>

      {/* Expenses List */}
      <Card className="p-6">
        <div className="space-y-4">
          {filteredExpenses.length > 0 ? (
            filteredExpenses.map((expense) => (
              <div
                key={expense.id}
                className="bg-dark-800/50 border border-dark-600/50 rounded-lg p-4 hover:border-green-500/20 transition-all duration-300"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-white font-medium">{expense.title}</h3>
                      <span className="bg-green-500/10 text-green-400 px-2 py-1 rounded-full text-xs">
                        {expense.category}
                      </span>
                      {expense.ai_suggested_category && expense.ai_suggested_category !== expense.category && (
                        <span className="bg-blue-500/10 text-blue-400 px-2 py-1 rounded-full text-xs">
                          AI: {expense.ai_suggested_category}
                        </span>
                      )}
                    </div>
                    
                    {expense.description && (
                      <p className="text-gray-400 text-sm mb-3">{expense.description}</p>
                    )}
                    
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {formatDate(expense.expense_date)}
                      </span>
                      {expense.vendor && (
                        <span>Vendor: {expense.vendor}</span>
                      )}
                      {expense.payment_method && (
                        <span>Payment: {expense.payment_method}</span>
                      )}
                      {expense.project && (
                        <span>Project: {expense.project}</span>
                      )}
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-xl font-semibold text-white">
                      {formatCurrency(expense.amount, expense.currency)}
                    </p>
                    {expense.tags && expense.tags.length > 0 && (
                      <div className="flex flex-wrap justify-end gap-1 mt-2">
                        {expense.tags.split(',').map((tag, index) => (
                          <span
                            key={index}
                            className="bg-gray-500/10 text-gray-400 px-2 py-1 rounded text-xs"
                          >
                            {tag.trim()}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-16">
              <div className="p-6 bg-dark-800/50 rounded-full w-24 h-24 mx-auto mb-6 flex items-center justify-center">
                <DollarSign className="h-12 w-12 text-gray-500" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">No expenses found</h3>
              <p className="text-gray-400 mb-6">
                {searchTerm || filterCategory 
                  ? 'Try adjusting your filters to see more results'
                  : 'Start tracking your business expenses'
                }
              </p>
              <button
                onClick={() => setShowCreateForm(true)}
                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-green-500/25 inline-flex items-center"
              >
                <Plus className="h-5 w-5 mr-2" />
                Add First Expense
              </button>
            </div>
          )}
        </div>
      </Card>

      {/* Create Expense Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-2xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-semibold text-white mb-6">Add New Expense</h3>
            
            <form onSubmit={handleCreateExpense} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Title *
                </label>
                <input
                  type="text"
                  required
                  value={newExpense.title}
                  onChange={(e) => setNewExpense(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
                  placeholder="Expense title"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Amount *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={newExpense.amount}
                    onChange={(e) => setNewExpense(prev => ({ ...prev, amount: e.target.value }))}
                    className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
                    placeholder="0.00"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Category *
                  </label>
                  <select
                    required
                    value={newExpense.category}
                    onChange={(e) => setNewExpense(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
                  >
                    <option value="">Select category</option>
                    {categories.map(category => (
                      <option key={category.id} value={category.name}>{category.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Date *
                </label>
                <input
                  type="date"
                  required
                  value={newExpense.expense_date}
                  onChange={(e) => setNewExpense(prev => ({ ...prev, expense_date: e.target.value }))}
                  className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Description
                </label>
                <textarea
                  value={newExpense.description}
                  onChange={(e) => setNewExpense(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
                  placeholder="Expense description"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Vendor
                  </label>
                  <input
                    type="text"
                    value={newExpense.vendor}
                    onChange={(e) => setNewExpense(prev => ({ ...prev, vendor: e.target.value }))}
                    className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
                    placeholder="Vendor name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Payment Method
                  </label>
                  <select
                    value={newExpense.payment_method}
                    onChange={(e) => setNewExpense(prev => ({ ...prev, payment_method: e.target.value }))}
                    className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
                  >
                    <option value="">Select method</option>
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="check">Check</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Project
                </label>
                <input
                  type="text"
                  value={newExpense.project}
                  onChange={(e) => setNewExpense(prev => ({ ...prev, project: e.target.value }))}
                  className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
                  placeholder="Project name"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Tags (comma-separated)
                </label>
                <input
                  type="text"
                  value={newExpense.tags}
                  onChange={(e) => setNewExpense(prev => ({ ...prev, tags: e.target.value }))}
                  className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50 transition-all duration-300"
                  placeholder="tag1, tag2, tag3"
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="flex-1 bg-dark-800 hover:bg-dark-700 text-white py-3 px-4 rounded-lg transition-colors duration-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white py-3 px-4 rounded-lg transition-all duration-300"
                >
                  Add Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}