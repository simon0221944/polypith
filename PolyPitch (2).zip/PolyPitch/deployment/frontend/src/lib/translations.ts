export const translations = {
  en: {
    common: {
      loading: 'Loading...',
      save: 'Save',
      cancel: 'Cancel',
      delete: 'Delete',
      edit: 'Edit',
      create: 'Create',
      back: 'Back',
      next: 'Next',
      previous: 'Previous',
      search: 'Search',
      filter: 'Filter',
      sort: 'Sort',
      actions: 'Actions'
    },
    nav: {
      home: 'Home',
      dashboard: 'Dashboard',
      proposals: 'Proposals',
      pricing: 'Pricing',
      login: 'Login',
      register: 'Register',
      logout: 'Logout',
      subscription: 'Subscription'
    },
    auth: {
      login: 'Login',
      register: 'Register',
      email: 'Email',
      password: 'Password',
      username: 'Username',
      confirmPassword: 'Confirm Password',
      forgotPassword: 'Forgot Password?',
      noAccount: "Don't have an account?",
      hasAccount: 'Already have an account?',
      signInWith: 'Sign in with',
      google: 'Google',
      facebook: 'Facebook',
      apple: 'Apple',
      orContinueWith: 'Or continue with email'
    },
    home: {
      title: 'AI-Powered Multilingual Sales Proposals',
      subtitle: 'Generate culturally-adapted sales proposals and e-commerce content for global markets using advanced AI technology.',
      getStarted: 'Get Started',
      learnMore: 'Learn More',
      features: {
        title: 'Powerful Features',
        subtitle: 'Everything you need for global sales success',
        ai: {
          title: 'AI-Powered Generation',
          description: 'Leverage GPT-4o to create compelling, culturally-adapted sales proposals in multiple languages.'
        },
        multilingual: {
          title: 'Multilingual Support',
          description: 'Generate content in 17+ languages with proper cultural adaptation for different markets.'
        },
        billing: {
          title: 'Flexible Billing',
          description: 'Stripe-powered subscription management with multiple tiers to fit your business needs.'
        }
      }
    },
    dashboard: {
      title: 'Dashboard',
      welcome: 'Welcome back',
      quickActions: 'Quick Actions',
      createProposal: 'Create New Proposal',
      viewProposals: 'View All Proposals',
      manageSubscription: 'Manage Subscription',
      stats: {
        totalProposals: 'Total Proposals',
        quotaUsed: 'Quota Used',
        quotaRemaining: 'Remaining',
        subscriptionTier: 'Subscription Tier'
      }
    },
    proposals: {
      title: 'Proposals',
      create: 'Create New Proposal',
      noProposals: 'No proposals found',
      createFirst: 'Create your first proposal to get started',
      filters: {
        all: 'All Proposals',
        recent: 'Recent',
        country: 'Country',
        language: 'Language'
      },
      form: {
        title: 'Proposal Title',
        targetCountry: 'Target Country',
        targetLanguage: 'Target Language',
        productDescription: 'Product Description',
        companyInfo: 'Company Information',
        targetAudience: 'Target Audience',
        generate: 'Generate Proposal',
        generating: 'Generating...'
      }
    },
    pricing: {
      title: 'Choose Your Plan',
      subtitle: 'Flexible pricing for every business size',
      free: {
        name: 'Free',
        price: '$0',
        period: '/month',
        features: [
          '3 proposals per month',
          'Basic AI generation',
          '17+ languages',
          'Email support'
        ]
      },
      basic: {
        name: 'Basic',
        price: '$29',
        period: '/month',
        features: [
          '50 proposals per month',
          'Advanced AI features',
          'All languages',
          'Priority support',
          'Export to PDF'
        ]
      },
      premium: {
        name: 'Premium',
        price: '$79',
        period: '/month',
        features: [
          'Unlimited proposals',
          'Premium AI models',
          'Custom templates',
          'API access',
          'White-label options'
        ]
      },
      mostPopular: 'Most Popular',
      subscribe: 'Subscribe',
      contactSales: 'Contact Sales'
    },
    subscription: {
      title: 'Subscription Management',
      currentPlan: 'Current Plan',
      usage: 'Usage',
      billingHistory: 'Billing History',
      manageBilling: 'Manage Billing',
      upgrade: 'Upgrade Plan',
      cancel: 'Cancel Subscription'
    },
    calendar: {
      title: 'Calendar',
      appointments: 'Appointments',
      schedule: 'Schedule',
      createAppointment: 'Create Appointment',
      editAppointment: 'Edit Appointment',
      deleteAppointment: 'Delete Appointment',
      noAppointments: 'No appointments found',
      conflictDetected: 'Conflict detected',
      suggestTime: 'Suggest Optimal Time',
      settings: 'Calendar Settings',
      workingHours: 'Working Hours',
      breakDuration: 'Break Duration',
      workingDays: 'Working Days',
      timezone: 'Timezone'
    },
    expenses: {
      title: 'Expenses',
      addExpense: 'Add Expense',
      editExpense: 'Edit Expense',
      deleteExpense: 'Delete Expense',
      noExpenses: 'No expenses found',
      summary: 'Summary',
      categories: 'Categories',
      analysis: 'Analysis',
      optimize: 'Optimize',
      export: 'Export',
      amount: 'Amount',
      category: 'Category',
      vendor: 'Vendor',
      project: 'Project',
      paymentMethod: 'Payment Method',
      receipt: 'Receipt',
      recurring: 'Recurring',
      aiSuggestion: 'AI Suggestion'
    }
  },
  es: {
    common: {
      loading: 'Cargando...',
      save: 'Guardar',
      cancel: 'Cancelar',
      delete: 'Eliminar',
      edit: 'Editar',
      create: 'Crear',
      back: 'Atrás',
      next: 'Siguiente',
      previous: 'Anterior',
      search: 'Buscar',
      filter: 'Filtrar',
      sort: 'Ordenar',
      actions: 'Acciones'
    },
    nav: {
      home: 'Inicio',
      dashboard: 'Panel',
      proposals: 'Propuestas',
      pricing: 'Precios',
      login: 'Iniciar Sesión',
      register: 'Registrarse',
      logout: 'Cerrar Sesión',
      subscription: 'Suscripción'
    },
    auth: {
      login: 'Iniciar Sesión',
      register: 'Registrarse',
      email: 'Correo Electrónico',
      password: 'Contraseña',
      username: 'Nombre de Usuario',
      confirmPassword: 'Confirmar Contraseña',
      forgotPassword: '¿Olvidaste tu contraseña?',
      noAccount: '¿No tienes una cuenta?',
      hasAccount: '¿Ya tienes una cuenta?',
      signInWith: 'Iniciar sesión con',
      google: 'Google',
      facebook: 'Facebook',
      apple: 'Apple',
      orContinueWith: 'O continuar con correo'
    },
    home: {
      title: 'Propuestas de Ventas Multilingües con IA',
      subtitle: 'Genera propuestas de ventas y contenido de comercio electrónico adaptado culturalmente para mercados globales usando tecnología de IA avanzada.',
      getStarted: 'Comenzar',
      learnMore: 'Saber Más',
      features: {
        title: 'Características Poderosas',
        subtitle: 'Todo lo que necesitas para el éxito de ventas globales',
        ai: {
          title: 'Generación con IA',
          description: 'Aprovecha GPT-4o para crear propuestas de ventas convincentes y adaptadas culturalmente en múltiples idiomas.'
        },
        multilingual: {
          title: 'Soporte Multilingüe',
          description: 'Genera contenido en más de 17 idiomas con adaptación cultural adecuada para diferentes mercados.'
        },
        billing: {
          title: 'Facturación Flexible',
          description: 'Gestión de suscripciones con Stripe con múltiples niveles para satisfacer las necesidades de tu negocio.'
        }
      }
    },
    dashboard: {
      title: 'Panel de Control',
      welcome: 'Bienvenido de nuevo',
      quickActions: 'Acciones Rápidas',
      createProposal: 'Crear Nueva Propuesta',
      viewProposals: 'Ver Todas las Propuestas',
      manageSubscription: 'Gestionar Suscripción',
      stats: {
        totalProposals: 'Propuestas Totales',
        quotaUsed: 'Cuota Utilizada',
        quotaRemaining: 'Restante',
        subscriptionTier: 'Nivel de Suscripción'
      }
    },
    proposals: {
      title: 'Propuestas',
      create: 'Crear Nueva Propuesta',
      noProposals: 'No se encontraron propuestas',
      createFirst: 'Crea tu primera propuesta para comenzar',
      filters: {
        all: 'Todas las Propuestas',
        recent: 'Recientes',
        country: 'País',
        language: 'Idioma'
      },
      form: {
        title: 'Título de la Propuesta',
        targetCountry: 'País Objetivo',
        targetLanguage: 'Idioma Objetivo',
        productDescription: 'Descripción del Producto',
        companyInfo: 'Información de la Empresa',
        targetAudience: 'Audiencia Objetivo',
        generate: 'Generar Propuesta',
        generating: 'Generando...'
      }
    },
    pricing: {
      title: 'Elige Tu Plan',
      subtitle: 'Precios flexibles para cada tamaño de negocio',
      free: {
        name: 'Gratis',
        price: '$0',
        period: '/mes',
        features: [
          '3 propuestas por mes',
          'Generación básica de IA',
          'Más de 17 idiomas',
          'Soporte por correo'
        ]
      },
      basic: {
        name: 'Básico',
        price: '$29',
        period: '/mes',
        features: [
          '50 propuestas por mes',
          'Características avanzadas de IA',
          'Todos los idiomas',
          'Soporte prioritario',
          'Exportar a PDF'
        ]
      },
      premium: {
        name: 'Premium',
        price: '$79',
        period: '/mes',
        features: [
          'Propuestas ilimitadas',
          'Modelos de IA premium',
          'Plantillas personalizadas',
          'Acceso a API',
          'Opciones de marca blanca'
        ]
      },
      mostPopular: 'Más Popular',
      subscribe: 'Suscribirse',
      contactSales: 'Contactar Ventas'
    },
    subscription: {
      title: 'Gestión de Suscripción',
      currentPlan: 'Plan Actual',
      usage: 'Uso',
      billingHistory: 'Historial de Facturación',
      manageBilling: 'Gestionar Facturación',
      upgrade: 'Actualizar Plan',
      cancel: 'Cancelar Suscripción'
    }
  },
  it: {
    common: {
      loading: 'Caricamento...',
      save: 'Salva',
      cancel: 'Annulla',
      delete: 'Elimina',
      edit: 'Modifica',
      create: 'Crea',
      back: 'Indietro',
      next: 'Avanti',
      previous: 'Precedente',
      search: 'Cerca',
      filter: 'Filtra',
      sort: 'Ordina',
      actions: 'Azioni'
    },
    nav: {
      home: 'Home',
      dashboard: 'Dashboard',
      proposals: 'Proposte',
      pricing: 'Prezzi',
      login: 'Accedi',
      register: 'Registrati',
      logout: 'Disconnetti',
      subscription: 'Abbonamento'
    },
    auth: {
      login: 'Accedi',
      register: 'Registrati',
      email: 'Email',
      password: 'Password',
      username: 'Nome Utente',
      confirmPassword: 'Conferma Password',
      forgotPassword: 'Password dimenticata?',
      noAccount: 'Non hai un account?',
      hasAccount: 'Hai già un account?',
      signInWith: 'Accedi con',
      google: 'Google',
      facebook: 'Facebook',
      apple: 'Apple',
      orContinueWith: 'O continua con email'
    },
    home: {
      title: 'Proposte di Vendita Multilingue con IA',
      subtitle: 'Genera proposte di vendita e contenuti e-commerce culturalmente adattati per mercati globali usando tecnologia IA avanzata.',
      getStarted: 'Inizia',
      learnMore: 'Scopri di Più',
      features: {
        title: 'Caratteristiche Potenti',
        subtitle: 'Tutto ciò che serve per il successo nelle vendite globali',
        ai: {
          title: 'Generazione con IA',
          description: 'Sfrutta GPT-4o per creare proposte di vendita convincenti e culturalmente adattate in più lingue.'
        },
        multilingual: {
          title: 'Supporto Multilingue',
          description: 'Genera contenuto in oltre 17 lingue con adattamento culturale appropriato per diversi mercati.'
        },
        billing: {
          title: 'Fatturazione Flessibile',
          description: 'Gestione abbonamenti con Stripe con più livelli per soddisfare le esigenze della tua attività.'
        }
      }
    },
    dashboard: {
      title: 'Dashboard',
      welcome: 'Bentornato',
      quickActions: 'Azioni Rapide',
      createProposal: 'Crea Nuova Proposta',
      viewProposals: 'Visualizza Tutte le Proposte',
      manageSubscription: 'Gestisci Abbonamento',
      stats: {
        totalProposals: 'Proposte Totali',
        quotaUsed: 'Quota Utilizzata',
        quotaRemaining: 'Rimanente',
        subscriptionTier: 'Livello Abbonamento'
      }
    },
    proposals: {
      title: 'Proposte',
      create: 'Crea Nuova Proposta',
      noProposals: 'Nessuna proposta trovata',
      createFirst: 'Crea la tua prima proposta per iniziare',
      filters: {
        all: 'Tutte le Proposte',
        recent: 'Recenti',
        country: 'Paese',
        language: 'Lingua'
      },
      form: {
        title: 'Titolo Proposta',
        targetCountry: 'Paese Target',
        targetLanguage: 'Lingua Target',
        productDescription: 'Descrizione Prodotto',
        companyInfo: 'Informazioni Azienda',
        targetAudience: 'Pubblico Target',
        generate: 'Genera Proposta',
        generating: 'Generazione...'
      }
    },
    pricing: {
      title: 'Scegli il Tuo Piano',
      subtitle: 'Prezzi flessibili per ogni dimensione aziendale',
      free: {
        name: 'Gratuito',
        price: '$0',
        period: '/mese',
        features: [
          '3 proposte al mese',
          'Generazione IA di base',
          'Oltre 17 lingue',
          'Supporto email'
        ]
      },
      basic: {
        name: 'Base',
        price: '$29',
        period: '/mese',
        features: [
          '50 proposte al mese',
          'Funzioni IA avanzate',
          'Tutte le lingue',
          'Supporto prioritario',
          'Esporta in PDF'
        ]
      },
      premium: {
        name: 'Premium',
        price: '$79',
        period: '/mese',
        features: [
          'Proposte illimitate',
          'Modelli IA premium',
          'Template personalizzati',
          'Accesso API',
          'Opzioni white-label'
        ]
      },
      mostPopular: 'Più Popolare',
      subscribe: 'Abbonati',
      contactSales: 'Contatta Vendite'
    },
    subscription: {
      title: 'Gestione Abbonamento',
      currentPlan: 'Piano Attuale',
      usage: 'Utilizzo',
      billingHistory: 'Cronologia Fatturazione',
      manageBilling: 'Gestisci Fatturazione',
      upgrade: 'Aggiorna Piano',
      cancel: 'Cancella Abbonamento'
    }
  }
}