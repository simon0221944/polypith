import os
from app import db
from models import User, Proposal
from flask import current_app
from sqlalchemy import text

def get_database_connection():
    """Get database connection info"""
    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        raise Exception("DATABASE_URL environment variable not set")
    
    return database_url

def test_database_connection():
    """Test database connectivity"""
    try:
        # Test the connection with a simple query
        result = db.session.execute(text("SELECT 1")).fetchone()
        current_app.logger.info("Database connection test successful")
        return True
    except Exception as e:
        current_app.logger.error(f"Database connection test failed: {str(e)}")
        return False

def get_user_statistics(user_id):
    """Get user statistics from database"""
    try:
        user = User.query.get(user_id)
        if not user:
            return None
        
        proposal_count = Proposal.query.filter_by(user_id=user_id).count()
        
        # Get recent proposals
        recent_proposals = Proposal.query.filter_by(user_id=user_id)\
            .order_by(Proposal.created_at.desc())\
            .limit(5)\
            .all()
        
        return {
            'user_id': user_id,
            'username': user.username,
            'email': user.email,
            'subscription_tier': user.subscription_tier,
            'total_proposals': proposal_count,
            'quota_used': user.proposals_used,
            'quota_limit': user.proposal_quota,
            'recent_proposals': [
                {
                    'id': p.id,
                    'title': p.title,
                    'target_country': p.target_country,
                    'created_at': p.created_at.isoformat()
                } for p in recent_proposals
            ]
        }
        
    except Exception as e:
        current_app.logger.error(f"Error fetching user statistics: {str(e)}")
        raise Exception(f"Failed to fetch user statistics: {str(e)}")

def backup_proposal(proposal_id):
    """Create a backup of proposal data"""
    try:
        proposal = Proposal.query.get(proposal_id)
        if not proposal:
            return None
        
        backup_data = {
            'id': proposal.id,
            'user_id': proposal.user_id,
            'title': proposal.title,
            'target_country': proposal.target_country,
            'target_language': proposal.target_language,
            'product_description': proposal.product_description,
            'company_info': proposal.company_info,
            'target_audience': proposal.target_audience,
            'generated_content': proposal.generated_content,
            'created_at': proposal.created_at.isoformat(),
            'updated_at': proposal.updated_at.isoformat()
        }
        
        current_app.logger.info(f"Backup created for proposal {proposal_id}")
        return backup_data
        
    except Exception as e:
        current_app.logger.error(f"Error backing up proposal {proposal_id}: {str(e)}")
        raise Exception(f"Failed to backup proposal: {str(e)}")

def search_proposals(user_id, search_term, limit=20):
    """Search user's proposals by title or content"""
    try:
        search_pattern = f"%{search_term}%"
        
        proposals = Proposal.query.filter_by(user_id=user_id)\
            .filter(
                db.or_(
                    Proposal.title.ilike(search_pattern),
                    Proposal.product_description.ilike(search_pattern),
                    Proposal.target_country.ilike(search_pattern)
                )
            )\
            .order_by(Proposal.created_at.desc())\
            .limit(limit)\
            .all()
        
        results = []
        for proposal in proposals:
            results.append({
                'id': proposal.id,
                'title': proposal.title,
                'target_country': proposal.target_country,
                'target_language': proposal.target_language,
                'created_at': proposal.created_at.isoformat(),
                'excerpt': proposal.product_description[:200] + '...' if len(proposal.product_description) > 200 else proposal.product_description
            })
        
        return results
        
    except Exception as e:
        current_app.logger.error(f"Error searching proposals: {str(e)}")
        raise Exception(f"Failed to search proposals: {str(e)}")

def cleanup_old_data():
    """Clean up old data based on retention policies"""
    try:
        # This is a placeholder for data cleanup logic
        # In a real implementation, you might want to:
        # - Archive old proposals
        # - Clean up expired sessions
        # - Remove inactive users (with proper notification)
        
        current_app.logger.info("Data cleanup process completed")
        return True
        
    except Exception as e:
        current_app.logger.error(f"Error during data cleanup: {str(e)}")
        return False
