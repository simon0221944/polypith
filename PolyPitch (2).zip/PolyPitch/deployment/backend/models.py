from app import db
from flask_login import UserMixin
from datetime import datetime
from sqlalchemy import func

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Subscription fields
    stripe_customer_id = db.Column(db.String(255))
    subscription_status = db.Column(db.String(50), default='free')  # free, active, canceled, past_due
    subscription_tier = db.Column(db.String(50), default='free')  # free, basic, premium
    proposal_quota = db.Column(db.Integer, default=3)  # Monthly quota
    proposals_used = db.Column(db.Integer, default=0)
    quota_reset_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    proposals = db.relationship('Proposal', backref='user', lazy=True)
    calendars = db.relationship('Calendar', backref='user', lazy=True)
    appointments = db.relationship('Appointment', backref='user', lazy=True)
    expenses = db.relationship('Expense', backref='user', lazy=True)
    expense_categories = db.relationship('ExpenseCategory', backref='user', lazy=True)

    def can_generate_proposal(self):
        """Check if user has remaining quota for proposal generation"""
        return self.proposals_used < self.proposal_quota

    def use_proposal_quota(self):
        """Increment used proposals count"""
        self.proposals_used += 1
        db.session.commit()

    def reset_quota_if_needed(self):
        """Reset quota if month has passed"""
        now = datetime.utcnow()
        if now >= self.quota_reset_date:
            self.proposals_used = 0
            # Set next reset date to next month
            if now.month == 12:
                self.quota_reset_date = now.replace(year=now.year + 1, month=1, day=1)
            else:
                self.quota_reset_date = now.replace(month=now.month + 1, day=1)
            db.session.commit()

class Proposal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    target_country = db.Column(db.String(100), nullable=False)
    target_language = db.Column(db.String(50), nullable=False)
    product_description = db.Column(db.Text, nullable=False)
    company_info = db.Column(db.Text)
    target_audience = db.Column(db.Text)
    generated_content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SubscriptionPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)  # free, basic, pro, enterprise
    stripe_price_id = db.Column(db.String(100), nullable=False)
    proposal_quota = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='EUR')
    features = db.Column(db.Text)  # JSON string of plan features
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'stripe_price_id': self.stripe_price_id,
            'proposal_quota': self.proposal_quota,
            'price': self.price,
            'currency': self.currency,
            'features': self.features,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat()
        }


class Calendar(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False, default='My Calendar')
    timezone = db.Column(db.String(50), default='UTC')
    working_hours_start = db.Column(db.Time, default=datetime.strptime('09:00', '%H:%M').time())
    working_hours_end = db.Column(db.Time, default=datetime.strptime('17:00', '%H:%M').time())
    working_days = db.Column(db.String(20), default='1,2,3,4,5')  # Monday-Friday (1-7)
    break_duration = db.Column(db.Integer, default=15)  # minutes
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    appointments = db.relationship('Appointment', backref='calendar', lazy=True, cascade='all, delete-orphan')


class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    calendar_id = db.Column(db.Integer, db.ForeignKey('calendar.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default='scheduled')  # scheduled, completed, cancelled
    location = db.Column(db.String(200))
    attendees = db.Column(db.Text)  # JSON string of attendee emails
    reminder_minutes = db.Column(db.Integer, default=15)
    recurring = db.Column(db.Boolean, default=False)
    recurring_pattern = db.Column(db.String(50))  # daily, weekly, monthly
    recurring_end_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat(),
            'status': self.status,
            'location': self.location,
            'attendees': self.attendees,
            'reminder_minutes': self.reminder_minutes,
            'recurring': self.recurring,
            'recurring_pattern': self.recurring_pattern,
            'recurring_end_date': self.recurring_end_date.isoformat() if self.recurring_end_date else None,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }


class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='USD')
    category = db.Column(db.String(50), nullable=False)
    ai_suggested_category = db.Column(db.String(50))
    expense_date = db.Column(db.Date, nullable=False)
    receipt_url = db.Column(db.String(500))
    payment_method = db.Column(db.String(50))  # cash, card, bank_transfer, etc.
    vendor = db.Column(db.String(100))
    project = db.Column(db.String(100))
    is_recurring = db.Column(db.Boolean, default=False)
    recurring_frequency = db.Column(db.String(20))  # monthly, quarterly, yearly
    tags = db.Column(db.String(200))  # comma-separated tags
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'amount': self.amount,
            'currency': self.currency,
            'category': self.category,
            'ai_suggested_category': self.ai_suggested_category,
            'expense_date': self.expense_date.isoformat(),
            'receipt_url': self.receipt_url,
            'payment_method': self.payment_method,
            'vendor': self.vendor,
            'project': self.project,
            'is_recurring': self.is_recurring,
            'recurring_frequency': self.recurring_frequency,
            'tags': self.tags,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }


class ExpenseCategory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.String(200))
    color = db.Column(db.String(7), default='#FFA500')  # hex color code
    budget_limit = db.Column(db.Float)  # monthly budget limit
    is_default = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'color': self.color,
            'budget_limit': self.budget_limit,
            'is_default': self.is_default,
            'created_at': self.created_at.isoformat()
        }
