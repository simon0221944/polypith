#!/usr/bin/env python3
"""
Database initialization script for PolyPitch on Hostinger
Run this after uploading files and configuring environment variables
"""

import os
from main import app, db
from models import User, Proposal, SubscriptionPlan, Calendar, Appointment, Expense, ExpenseCategory

def init_database():
    """Initialize database tables and default data"""
    
    with app.app_context():
        try:
            # Create all tables
            print("Creating database tables...")
            db.create_all()
            
            # Check if subscription plans exist
            if not SubscriptionPlan.query.first():
                print("Creating default subscription plans...")
                
                # Create default subscription plans
                plans = [
                    {
                        'name': 'free',
                        'stripe_price_id': os.getenv('STRIPE_PRICE_FREE', ''),
                        'proposal_quota': 3,
                        'price': 0.0,
                        'currency': 'EUR',
                        'features': '{"basic": true, "proposals": 3}',
                        'is_active': True
                    },
                    {
                        'name': 'basic',
                        'stripe_price_id': os.getenv('STRIPE_PRICE_BASIC', ''),
                        'proposal_quota': 25,
                        'price': 9.99,
                        'currency': 'EUR',
                        'features': '{"basic": true, "proposals": 25, "priority_support": true}',
                        'is_active': True
                    },
                    {
                        'name': 'pro',
                        'stripe_price_id': os.getenv('STRIPE_PRICE_PRO', ''),
                        'proposal_quota': 100,
                        'price': 19.99,
                        'currency': 'EUR',
                        'features': '{"basic": true, "proposals": 100, "priority_support": true, "analytics": true}',
                        'is_active': True
                    },
                    {
                        'name': 'enterprise',
                        'stripe_price_id': os.getenv('STRIPE_PRICE_ENTERPRISE', ''),
                        'proposal_quota': 1000,
                        'price': 49.99,
                        'currency': 'EUR',
                        'features': '{"basic": true, "proposals": 1000, "priority_support": true, "analytics": true, "custom": true}',
                        'is_active': True
                    }
                ]
                
                for plan_data in plans:
                    plan = SubscriptionPlan(**plan_data)
                    db.session.add(plan)
                
                db.session.commit()
                print("Subscription plans created successfully!")
            
            print("Database initialization completed successfully!")
            return True
            
        except Exception as e:
            print(f"Error initializing database: {str(e)}")
            return False

if __name__ == '__main__':
    success = init_database()
    if success:
        print("\n✅ Database ready for PolyPitch!")
        print("Your platform is now ready to use.")
    else:
        print("\n❌ Database initialization failed.")
        print("Please check your environment variables and database connection.")