import jwt
import os
from functools import wraps
from flask import request, jsonify, current_app
from models import User

def token_required(f):
    """
    Decorator to require JWT token for API endpoints
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Check for token in Authorization header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]  # Bearer <token>
            except IndexError:
                return jsonify({'error': 'Invalid token format'}), 401
        
        if not token:
            return jsonify({'error': 'Token is missing'}), 401
        
        try:
            # Decode the token
            data = jwt.decode(token, current_app.secret_key, algorithms=['HS256'])
            current_user = User.query.get(data['user_id'])
            
            if not current_user:
                return jsonify({'error': 'Invalid token'}), 401
                
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token has expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Invalid token'}), 401
        except Exception as e:
            current_app.logger.error(f"Token validation error: {str(e)}")
            return jsonify({'error': 'Token validation failed'}), 401
        
        return f(current_user, *args, **kwargs)
    
    return decorated

def generate_token(user_id, expiration_days=30):
    """
    Generate JWT token for user
    
    Args:
        user_id (int): User ID
        expiration_days (int): Token expiration in days
    
    Returns:
        str: JWT token
    """
    try:
        import datetime
        
        payload = {
            'user_id': user_id,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(days=expiration_days),
            'iat': datetime.datetime.utcnow()
        }
        
        token = jwt.encode(payload, current_app.secret_key, algorithm='HS256')
        return token
        
    except Exception as e:
        current_app.logger.error(f"Token generation error: {str(e)}")
        raise Exception("Failed to generate token")

def decode_token(token):
    """
    Decode JWT token and return user data
    
    Args:
        token (str): JWT token
    
    Returns:
        dict: Token payload or None if invalid
    """
    try:
        data = jwt.decode(token, current_app.secret_key, algorithms=['HS256'])
        return data
        
    except jwt.ExpiredSignatureError:
        current_app.logger.warning("Expired token provided")
        return None
    except jwt.InvalidTokenError:
        current_app.logger.warning("Invalid token provided")
        return None
    except Exception as e:
        current_app.logger.error(f"Token decode error: {str(e)}")
        return None

def validate_user_permissions(user, required_tier=None):
    """
    Validate user permissions based on subscription tier
    
    Args:
        user (User): User object
        required_tier (str): Required subscription tier
    
    Returns:
        bool: True if user has required permissions
    """
    try:
        if not user:
            return False
        
        # Check if user account is active
        if user.subscription_status in ['canceled', 'past_due']:
            return False
        
        # Check subscription tier requirements
        if required_tier:
            tier_hierarchy = {
                'free': 0,
                'basic': 1,
                'premium': 2
            }
            
            user_tier_level = tier_hierarchy.get(user.subscription_tier, 0)
            required_tier_level = tier_hierarchy.get(required_tier, 0)
            
            if user_tier_level < required_tier_level:
                return False
        
        return True
        
    except Exception as e:
        current_app.logger.error(f"Permission validation error: {str(e)}")
        return False

def refresh_token(token):
    """
    Refresh JWT token if it's close to expiration
    
    Args:
        token (str): Current JWT token
    
    Returns:
        str: New token or original if not needed
    """
    try:
        import datetime
        
        data = decode_token(token)
        if not data:
            return None
        
        # Check if token expires within 7 days
        exp_timestamp = data.get('exp')
        if exp_timestamp:
            exp_date = datetime.datetime.fromtimestamp(exp_timestamp)
            days_until_expiry = (exp_date - datetime.datetime.utcnow()).days
            
            if days_until_expiry <= 7:
                # Generate new token
                return generate_token(data['user_id'])
        
        return token  # Return original token if refresh not needed
        
    except Exception as e:
        current_app.logger.error(f"Token refresh error: {str(e)}")
        return None
