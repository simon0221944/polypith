# PolyPitch Hostinger Deployment Guide

## Project Overview
PolyPitch is a full-stack SaaS platform with React frontend and Flask backend, ready for deployment to Hostinger.

## Architecture
- **Frontend**: React + TypeScript + Vite (static build)
- **Backend**: Flask + Python 3.11 + PostgreSQL
- **Database**: PostgreSQL (requires Hostinger database)
- **External Services**: Stripe, OpenAI, Supabase Auth

## Pre-Migration Checklist

### 1. Environment Variables Required
Backend (.env):
```
DATABASE_URL=postgresql://username:password@host:port/database
OPENAI_API_KEY=your_openai_key
STRIPE_SECRET_KEY=your_stripe_secret
STRIPE_PRICE_FREE=price_id_for_free_plan
STRIPE_PRICE_BASIC=price_id_for_basic_plan
STRIPE_PRICE_PRO=price_id_for_pro_plan
STRIPE_PRICE_ENTERPRISE=price_id_for_enterprise_plan
STRIPE_WEBHOOK_SECRET=your_webhook_secret
SESSION_SECRET=your_session_secret
```

Frontend (.env):
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_key
VITE_API_BASE_URL=https://yourdomain.com/api
```

### 2. Database Setup on Hostinger
1. Create PostgreSQL database in Hostinger control panel
2. Note connection details (host, port, database name, username, password)
3. Run database migrations using the Flask app

### 3. File Structure for Upload
```
polypitch/
├── backend/
│   ├── api_routes/
│   ├── services/
│   ├── utils/
│   ├── templates/
│   ├── main.py
│   ├── models.py
│   ├── requirements.txt
│   └── .env
├── frontend/
│   ├── dist/ (built files)
│   └── .env
└── .htaccess (for routing)
```

## Deployment Steps

### Step 1: Backend Deployment
1. Upload backend files to subdomain or subfolder
2. Install Python dependencies: `pip install -r requirements.txt`
3. Set up environment variables
4. Configure WSGI/CGI for Flask app
5. Test API endpoints

### Step 2: Frontend Deployment
1. Build production files: `npm run build`
2. Upload dist/ contents to main domain
3. Configure .htaccess for React routing
4. Update API base URL to backend location

### Step 3: Database Migration
1. Create PostgreSQL database on Hostinger
2. Update DATABASE_URL in backend .env
3. Run: `python -c "from main import app, db; app.app_context().push(); db.create_all()"`

### Step 4: Domain Configuration
- Frontend: Main domain (yourdomain.com)
- Backend API: Subdomain (api.yourdomain.com) or subfolder (/api)
- Update CORS settings for production domain

## Testing Checklist
- [ ] User registration/login works
- [ ] AI proposal generation functions
- [ ] Calendar appointments can be created
- [ ] Expense tracking saves data
- [ ] Stripe subscription flow completes
- [ ] All API endpoints respond correctly

## Post-Deployment
1. Update Stripe webhook URL to production domain
2. Test payment flows in Stripe dashboard
3. Verify email notifications work
4. Monitor error logs for any issues

## Support
- Hostinger supports Python/Flask applications
- Use cPanel File Manager or FTP for uploads
- Database can be managed through phpMyAdmin
- SSL certificates available through Let's Encrypt