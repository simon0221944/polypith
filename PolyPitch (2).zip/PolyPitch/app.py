import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Enable CORS for frontend integration
CORS(app, origins=["*"], supports_credentials=True)

# Configure the database - use Replit's built-in PostgreSQL if Supabase fails
database_url = os.environ.get("DATABASE_URL")
if not database_url or "supabase" in database_url:
    # Fallback to Replit's built-in PostgreSQL
    database_url = os.environ.get("DATABASE_URL", "sqlite:///polypitch.db")

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)

# Import routes
from api_routes import api, auth, stripe_routes
from api_routes.calendar import calendar_bp
from api_routes.expense import expense_bp

# Register blueprints
app.register_blueprint(api.bp)
app.register_blueprint(auth.bp)
app.register_blueprint(stripe_routes.bp)
app.register_blueprint(calendar_bp)
app.register_blueprint(expense_bp)

with app.app_context():
    try:
        # Import models to ensure tables are created
        import models
        db.create_all()
        logging.info("Database tables created successfully")
    except Exception as e:
        logging.error(f"Database initialization error: {str(e)}")
        # Continue without database for now
        pass

@app.route('/')
def index():
    return """
    <html>
    <head>
        <title>PolyPitch API</title>
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container mt-5">
            <div class="text-center">
                <h1 class="display-4">PolyPitch API</h1>
                <p class="lead">AI-Powered Multilingual Sales Proposals</p>
                <div class="mt-4">
                    <h3>Available Endpoints:</h3>
                    <ul class="list-unstyled">
                        <li><code>POST /api/generate-proposal</code> - Generate AI proposal</li>
                        <li><code>GET /api/proposals</code> - Get user proposals</li>
                        <li><code>POST /api/register</code> - Register user</li>
                        <li><code>POST /api/login</code> - Login user</li>
                        <li><code>GET /calendar</code> - Get calendar settings</li>
                        <li><code>GET /appointments</code> - Get appointments</li>
                        <li><code>POST /appointments</code> - Create appointment</li>
                        <li><code>GET /expenses</code> - Get expenses</li>
                        <li><code>POST /expenses</code> - Create expense</li>
                        <li><code>POST /stripe/create-checkout-session</code> - Create subscription (requires plan parameter)</li>
                        <li><code>GET /stripe/subscription-plans</code> - Get available plans</li>
                        <li><code>POST /stripe/webhook</code> - Stripe webhook (with signature verification)</li>
                    </ul>
                </div>
            </div>
        </div>
    </body>
    </html>
    """

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)