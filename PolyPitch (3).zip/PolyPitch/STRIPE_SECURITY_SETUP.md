# Stripe Security Setup Guide

## 🔐 Security Issue Resolution

**IMPORTANT**: The Stripe webhook secret was previously hard-coded in documentation files. This has been fixed to protect your account security.

## Required Environment Variables

Set these environment variables in your Replit project secrets:

```bash
STRIPE_SECRET_KEY=sk_test_... # Your Stripe secret key from dashboard
STRIPE_WEBHOOK_SECRET=whsec_... # Generate new webhook secret (instructions below)
```

## How to Generate a New Webhook Secret

1. **Login to Stripe Dashboard**: https://dashboard.stripe.com
2. **Navigate to Webhooks**: Developers → Webhooks
3. **Find your webhook endpoint** or create a new one:
   - Endpoint URL: `https://your-replit-domain.replit.app/stripe/webhook`
   - Events to send: `checkout.session.completed`, `invoice.payment_succeeded`, `invoice.payment_failed`, `customer.subscription.updated`, `customer.subscription.deleted`
4. **Copy the Signing Secret**: Click on your webhook → Signing secret section → Reveal
5. **Add to Replit Secrets**: 
   - Go to your Replit project
   - Click the lock icon (Secrets)
   - Add `STRIPE_WEBHOOK_SECRET` with the value starting with `whsec_`

## Security Best Practices

- ✅ **Never commit API keys or webhook secrets to version control**
- ✅ **Use environment variables for all sensitive data**
- ✅ **Regenerate webhook secrets if they've been exposed**
- ✅ **Monitor webhook delivery in Stripe Dashboard**
- ✅ **Use test keys for development, live keys only for production**

## Verification

Run the validation script to ensure everything is configured correctly:

```bash
python validate_stripe_setup.py
```

This will verify:
- All Price IDs are valid
- Webhook secret is properly configured
- Pricing structure matches expectations

## Files That Have Been Secured

- `stripe_checkout_test_results.md` - Removed hard-coded webhook secret
- `validate_stripe_setup.py` - Updated to use environment variables only

The backend code in `api_routes/stripe_routes.py` and `services/stripe_service.py` already correctly uses `os.environ.get('STRIPE_WEBHOOK_SECRET')` for secure access.