# PolyPitch GitHub Export & Render Deployment Guide

## Quick Start

1. **Export to GitHub**
   - Copy all project files to your GitHub repository
   - Ensure `requirements-github.txt` is renamed to `requirements.txt`
   - Commit and push to GitHub

2. **Deploy on Render**
   - Connect your GitHub repository to Render
   - Use the provided `render.yaml` for automatic configuration
   - Set environment variables in Render dashboard

## Files for GitHub Export

### Core Application Files
- `main.py` - Application entry point
- `app.py` - Flask application setup
- `models.py` - Database models
- `wsgi.py` - Production WSGI configuration

### API Routes
- `api_routes/` - All API endpoints
  - `auth.py` - Authentication endpoints
  - `api.py` - Proposal generation endpoints
  - `calendar.py` - Calendar management
  - `expense.py` - Expense tracking
  - `stripe_routes.py` - Payment processing

### Services
- `services/` - External service integrations
  - `openai_service.py` - AI content generation
  - `stripe_service.py` - Payment processing
  - `supabase_service.py` - Database operations

### Utilities
- `utils/` - Helper functions
  - `auth_utils.py` - Authentication utilities
  - `validators.py` - Input validation

### Configuration Files
- `requirements-github.txt` - Python dependencies (rename to requirements.txt)
- `render.yaml` - Render deployment configuration
- `Procfile` - Process configuration for deployment
- `runtime.txt` - Python version specification
- `.env.example` - Environment variables template

## Render Deployment Steps

### 1. Create Render Account
- Sign up at render.com
- Connect your GitHub account

### 2. Create New Web Service
- Click "New" → "Web Service"
- Connect your GitHub repository
- Configure deployment settings

### 3. Environment Variables
Set these in Render dashboard:
- `OPENAI_API_KEY` - Your OpenAI API key
- `STRIPE_SECRET_KEY` - Your Stripe secret key
- `STRIPE_PRICE_*` - Your Stripe price IDs
- `STRIPE_WEBHOOK_SECRET` - Webhook secret
- `SESSION_SECRET` - Random secure string

### 4. Database Setup
- Render will automatically create PostgreSQL database
- `DATABASE_URL` will be auto-populated

### 5. Deploy
- Render will automatically build and deploy
- Your app will be available at `https://your-app-name.onrender.com`

## Post-Deployment Configuration

### Stripe Webhooks
Update webhook URL in Stripe dashboard:
```
https://your-app-name.onrender.com/stripe/webhook
```

### Frontend Configuration
Update your frontend's API base URL:
```
VITE_API_BASE_URL=https://your-app-name.onrender.com/api
```

## Production Considerations

### Database
- Render provides managed PostgreSQL
- Automatic backups included
- Connection pooling configured

### Security
- HTTPS enabled by default
- Environment variables encrypted
- Regular security updates

### Performance
- Auto-scaling based on traffic
- CDN integration available
- Monitoring and logging included

### Monitoring
- Built-in metrics dashboard
- Error tracking and alerts
- Performance monitoring

## Troubleshooting

### Common Issues
1. **Build Failures**: Check requirements.txt dependencies
2. **Database Errors**: Verify DATABASE_URL configuration
3. **API Errors**: Ensure all environment variables are set
4. **Payment Issues**: Update Stripe webhook URL

### Debug Commands
```bash
# Check logs
render logs

# Connect to database
render psql

# Environment check
render env
```

## Features Available After Deployment

- ✅ User authentication and registration
- ✅ AI-powered proposal generation (OpenAI GPT-4)
- ✅ Multilingual content support
- ✅ Calendar and appointment management
- ✅ Expense tracking with AI categorization
- ✅ Stripe subscription management
- ✅ RESTful API endpoints
- ✅ Production-ready security
- ✅ Automatic scaling
- ✅ SSL/HTTPS encryption

Your PolyPitch SaaS platform will be fully operational on Render!