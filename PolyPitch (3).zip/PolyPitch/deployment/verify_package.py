#!/usr/bin/env python3
"""
PolyPitch Deployment Package Verification Script
Ensures all files are properly configured for Hostinger migration
"""

import os
import sys
from pathlib import Path

def check_backend_package():
    """Verify backend package completeness"""
    print("🔍 Checking backend package...")
    
    required_files = [
        'main.py', 'models.py', 'app.py', 'wsgi.py', 
        'requirements.txt', '.env.template', 'init_database.py'
    ]
    
    required_dirs = ['api_routes', 'services', 'utils']
    
    backend_path = Path('deployment/backend')
    
    for file in required_files:
        if not (backend_path / file).exists():
            print(f"❌ Missing: {file}")
            return False
        else:
            print(f"✅ Found: {file}")
    
    for dir in required_dirs:
        if not (backend_path / dir).is_dir():
            print(f"❌ Missing directory: {dir}")
            return False
        else:
            print(f"✅ Found directory: {dir}")
    
    return True

def check_frontend_package():
    """Verify frontend package completeness"""
    print("\n🔍 Checking frontend package...")
    
    required_files = [
        'package.json', 'index.html', 'vite.config.ts',
        '.env.template', '.htaccess'
    ]
    
    required_dirs = ['src', 'public']
    
    frontend_path = Path('deployment/frontend')
    
    for file in required_files:
        if not (frontend_path / file).exists():
            print(f"❌ Missing: {file}")
            return False
        else:
            print(f"✅ Found: {file}")
    
    for dir in required_dirs:
        if not (frontend_path / dir).is_dir():
            print(f"❌ Missing directory: {dir}")
            return False
        else:
            print(f"✅ Found directory: {dir}")
    
    return True

def check_configuration_files():
    """Verify configuration templates"""
    print("\n🔍 Checking configuration templates...")
    
    # Check backend .env template
    backend_env = Path('deployment/backend/.env.template')
    if backend_env.exists():
        content = backend_env.read_text()
        required_vars = ['DATABASE_URL', 'OPENAI_API_KEY', 'STRIPE_SECRET_KEY', 'SESSION_SECRET']
        
        for var in required_vars:
            if var in content:
                print(f"✅ Backend env variable: {var}")
            else:
                print(f"❌ Missing backend env variable: {var}")
                return False
    
    # Check frontend .env template
    frontend_env = Path('deployment/frontend/.env.template')
    if frontend_env.exists():
        content = frontend_env.read_text()
        required_vars = ['VITE_SUPABASE_URL', 'VITE_API_BASE_URL']
        
        for var in required_vars:
            if var in content:
                print(f"✅ Frontend env variable: {var}")
            else:
                print(f"❌ Missing frontend env variable: {var}")
                return False
    
    return True

def generate_summary_report():
    """Generate deployment summary"""
    print("\n📊 DEPLOYMENT PACKAGE SUMMARY")
    print("=" * 50)
    
    backend_size = sum(f.stat().st_size for f in Path('deployment/backend').rglob('*') if f.is_file())
    frontend_size = sum(f.stat().st_size for f in Path('deployment/frontend').rglob('*') if f.is_file())
    
    print(f"Backend package size: {backend_size / 1024:.1f} KB")
    print(f"Frontend package size: {frontend_size / 1024:.1f} KB")
    print(f"Total package size: {(backend_size + frontend_size) / 1024:.1f} KB")
    
    print("\n📁 UPLOAD INSTRUCTIONS:")
    print("1. Upload 'deployment/backend/' contents to your API domain/subfolder")
    print("2. Upload 'deployment/frontend/' contents to your main domain")
    print("3. Configure .env files with your actual credentials")
    print("4. Run database initialization script")
    print("5. Test all endpoints and functionality")
    
    print("\n🚀 Your PolyPitch platform is ready for Hostinger!")

def main():
    """Main verification process"""
    print("🔥 PolyPitch Hostinger Migration Package Verification")
    print("=" * 60)
    
    if not Path('deployment').exists():
        print("❌ Deployment package not found!")
        print("Run the deployment script first to create the package.")
        return False
    
    backend_ok = check_backend_package()
    frontend_ok = check_frontend_package()
    config_ok = check_configuration_files()
    
    if backend_ok and frontend_ok and config_ok:
        print("\n✅ VERIFICATION PASSED!")
        print("All required files and configurations are present.")
        generate_summary_report()
        return True
    else:
        print("\n❌ VERIFICATION FAILED!")
        print("Some files or configurations are missing.")
        return False

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)