#!/usr/bin/env python3
"""
WSGI configuration for PolyPitch Flask application
For Hostinger deployment
"""

import sys
import os
from pathlib import Path

# Add the project directory to Python path
project_dir = Path(__file__).parent.absolute()
sys.path.insert(0, str(project_dir))

# Import the Flask application
from main import app

# WSGI callable
application = app

if __name__ == "__main__":
    app.run(debug=False, host='0.0.0.0', port=5000)