import json
import os
from openai import OpenAI
from flask import current_app

# the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
# do not change this unless explicitly requested by the user
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai_client = OpenAI(api_key=OPENAI_API_KEY)

def generate_multilingual_proposal(product_description, target_country, target_language, 
                                 company_info="", target_audience=""):
    """
    Generate AI-powered multilingual sales proposal using OpenAI GPT-4o
    
    Args:
        product_description (str): Description of the product/service
        target_country (str): Target country for localization
        target_language (str): Target language for the proposal
        company_info (str): Information about the company
        target_audience (str): Target audience description
    
    Returns:
        str: Generated proposal content in JSON format
    """
    try:
        # Construct the prompt for proposal generation
        prompt = f"""
        You are an expert international sales proposal writer with deep knowledge of cultural nuances and business practices across different countries.

        Generate a comprehensive, culturally-appropriate sales proposal with the following specifications:

        PRODUCT/SERVICE: {product_description}
        TARGET COUNTRY: {target_country}
        TARGET LANGUAGE: {target_language}
        COMPANY INFO: {company_info if company_info else "Not provided"}
        TARGET AUDIENCE: {target_audience if target_audience else "General business audience"}

        Requirements:
        1. Write the entire proposal in {target_language}
        2. Adapt content for {target_country} cultural context and business practices
        3. Include appropriate greetings, formalities, and closing remarks for the culture
        4. Use currency, measurements, and formats appropriate for {target_country}
        5. Consider local regulations, market conditions, and business etiquette
        6. Structure as a professional business proposal

        Proposal Structure:
        - Executive Summary
        - Problem Statement
        - Proposed Solution
        - Benefits & Value Proposition
        - Implementation Timeline
        - Pricing (in local currency if possible)
        - Terms & Conditions
        - Call to Action
        - Professional Closing

        Return the response as JSON with the following structure:
        {{
            "title": "Proposal title in {target_language}",
            "executive_summary": "Executive summary section",
            "problem_statement": "Problem statement section",
            "proposed_solution": "Proposed solution section",
            "benefits": "Benefits and value proposition section",
            "timeline": "Implementation timeline section",
            "pricing": "Pricing information section",
            "terms": "Terms and conditions section",
            "call_to_action": "Call to action section",
            "closing": "Professional closing section",
            "cultural_notes": "Key cultural adaptations made for {target_country}",
            "language": "{target_language}",
            "country": "{target_country}"
        }}
        """
        
        # Call OpenAI API
        response = openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert international sales proposal writer. Always respond with valid JSON format containing the complete proposal structure."
                },
                {
                    "role": "user", 
                    "content": prompt
                }
            ],
            response_format={"type": "json_object"},
            max_tokens=4000,
            temperature=0.7
        )
        
        # Parse and return the generated content
        generated_content = response.choices[0].message.content
        
        # Validate JSON format
        try:
            json.loads(generated_content)
        except json.JSONDecodeError:
            current_app.logger.error("OpenAI returned invalid JSON")
            raise Exception("Failed to generate properly formatted proposal")
        
        current_app.logger.info(f"Successfully generated proposal for {target_country} in {target_language}")
        return generated_content
        
    except Exception as e:
        current_app.logger.error(f"OpenAI proposal generation error: {str(e)}")
        raise Exception(f"Failed to generate proposal: {str(e)}")

def generate_product_content(product_description, content_type, target_country, target_language):
    """
    Generate AI-powered e-commerce product content
    
    Args:
        product_description (str): Description of the product
        content_type (str): Type of content (title, description, features, etc.)
        target_country (str): Target country for localization
        target_language (str): Target language
    
    Returns:
        str: Generated content in JSON format
    """
    try:
        prompt = f"""
        Generate {content_type} for an e-commerce product with cultural adaptation for {target_country}.

        PRODUCT: {product_description}
        CONTENT TYPE: {content_type}
        TARGET COUNTRY: {target_country}
        TARGET LANGUAGE: {target_language}

        Requirements:
        1. Write in {target_language}
        2. Adapt for {target_country} market preferences and culture
        3. Use appropriate tone and style for e-commerce
        4. Include relevant keywords for local SEO
        5. Consider local shopping behaviors and preferences

        Return as JSON:
        {{
            "content": "Generated content in {target_language}",
            "seo_keywords": ["keyword1", "keyword2", "keyword3"],
            "cultural_adaptations": "Key adaptations made for {target_country}",
            "content_type": "{content_type}",
            "language": "{target_language}",
            "country": "{target_country}"
        }}
        """
        
        response = openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert e-commerce content writer with expertise in international markets. Always respond with valid JSON."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            response_format={"type": "json_object"},
            max_tokens=2000,
            temperature=0.7
        )
        
        generated_content = response.choices[0].message.content
        
        # Validate JSON
        try:
            json.loads(generated_content)
        except json.JSONDecodeError:
            raise Exception("Failed to generate properly formatted content")
        
        return generated_content
        
    except Exception as e:
        current_app.logger.error(f"OpenAI content generation error: {str(e)}")
        raise Exception(f"Failed to generate content: {str(e)}")


def suggest_optimal_scheduling(calendar_settings, existing_appointments, duration_minutes, preferred_date=None, preferences=None):
    """AI-powered optimal scheduling suggestions"""
    try:
        prompt = f"""
        Analyze calendar data and suggest optimal appointment times.
        
        Calendar Settings:
        - Working hours: {calendar_settings['working_hours_start']} to {calendar_settings['working_hours_end']}
        - Working days: {calendar_settings['working_days']} (1=Monday, 7=Sunday)
        - Break duration: {calendar_settings['break_duration']} minutes
        - Timezone: {calendar_settings['timezone']}
        
        Existing Appointments: {json.dumps(existing_appointments, default=str)[:1000]}
        
        New Appointment:
        - Duration: {duration_minutes} minutes
        - Preferred date: {preferred_date or 'Next 7 days'}
        
        Provide 3 optimal time suggestions in JSON format:
        {{
            "suggestions": [
                {{
                    "start_time": "2025-01-15T10:00:00",
                    "end_time": "2025-01-15T11:00:00",
                    "confidence_score": 0.95,
                    "reasoning": "Why this time is optimal"
                }}
            ]
        }}
        """
        
        response = openai_client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024
            messages=[
                {"role": "system", "content": "You are an expert scheduling assistant. Always respond with valid JSON."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            max_tokens=1500,
            temperature=0.3
        )
        
        result = json.loads(response.choices[0].message.content)
        return result.get('suggestions', [])
        
    except Exception as e:
        current_app.logger.error(f"OpenAI scheduling suggestion error: {str(e)}")
        return []


def categorize_expense_with_ai(expense_description):
    """AI-powered expense categorization"""
    try:
        valid_categories = ['Travel', 'Office Supplies', 'Marketing', 'Software', 'Meals', 'Training', 'Utilities', 'Other']
        
        prompt = f"""
        Categorize this business expense into one of these categories:
        {', '.join(valid_categories)}
        
        Expense description: "{expense_description}"
        
        Return only the category name that best fits.
        """
        
        response = openai_client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024
            messages=[
                {"role": "system", "content": "You are an expert accountant specializing in business expense categorization."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=50,
            temperature=0.1
        )
        
        category = response.choices[0].message.content.strip()
        
        if category not in valid_categories:
            return 'Other'
        
        return category
        
    except Exception as e:
        current_app.logger.error(f"OpenAI expense categorization error: {str(e)}")
        return 'Other'


def analyze_expenses_with_ai(expense_data, month, year):
    """AI-powered expense analysis and optimization suggestions"""
    try:
        total_amount = sum(expense['amount'] for expense in expense_data)
        categories = {}
        for expense in expense_data:
            category = expense['category']
            categories[category] = categories.get(category, 0) + expense['amount']
        
        prompt = f"""
        Analyze business expenses for {month}/{year} and provide insights.
        
        Total: ${total_amount:.2f}
        Count: {len(expense_data)}
        Categories: {json.dumps(categories, indent=2)}
        
        Provide analysis in JSON format:
        {{
            "summary": "Brief overview of spending patterns",
            "insights": ["Key insight 1", "Key insight 2"],
            "optimization_suggestions": ["Suggestion 1", "Suggestion 2"],
            "category_analysis": {{
                "highest_category": "Category name",
                "optimization_priority": "Focus area"
            }},
            "budget_recommendations": {{
                "suggested_monthly_budget": 1000,
                "savings_potential": "Est. monthly savings"
            }}
        }}
        """
        
        response = openai_client.chat.completions.create(
            model="gpt-4o",  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024
            messages=[
                {"role": "system", "content": "You are a financial analyst. Always respond with valid JSON."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            max_tokens=2000,
            temperature=0.3
        )
        
        return json.loads(response.choices[0].message.content)
        
    except Exception as e:
        current_app.logger.error(f"OpenAI expense analysis error: {str(e)}")
        return {
            "summary": "Analysis temporarily unavailable",
            "insights": ["Unable to analyze expenses at this time"],
            "optimization_suggestions": ["Please try again later"],
            "category_analysis": {},
            "budget_recommendations": {}
        }
