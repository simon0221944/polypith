import os
import stripe
import logging
from datetime import datetime
from flask import current_app
from models import User, SubscriptionPlan

# Set Stripe API key
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')

# Subscription plan mapping
SUBSCRIPTION_PLANS = {
    'free': {
        'stripe_price_id': os.environ.get('STRIPE_PRICE_FREE', 'price_1RduWuL7qTQUkVTLZF0zYQdr'),
        'price': 0.00,
        'currency': 'EUR',
        'proposal_quota': 3
    },
    'basic': {
        'stripe_price_id': os.environ.get('STRIPE_PRICE_BASIC', 'price_1RduXlL7qTQUkVTL0Iv9WoI2'),
        'price': 9.99,
        'currency': 'EUR',
        'proposal_quota': 50
    },
    'pro': {
        'stripe_price_id': os.environ.get('STRIPE_PRICE_PRO', 'price_1Rbec7L7qTQUkVTL7G3EZV8G'),
        'price': 19.99,
        'currency': 'EUR',
        'proposal_quota': 200
    },
    'enterprise': {
        'stripe_price_id': os.environ.get('STRIPE_PRICE_ENTERPRISE', 'price_1RbeeYL7qTQUkVTLAM8VLrg1'),
        'price': 49.99,
        'currency': 'EUR',
        'proposal_quota': 1000
    }
}

def create_checkout_session(plan_name_or_price_id, customer_email, customer_id=None, user_id=None, 
                          success_url=None, cancel_url=None):
    """
    Create a Stripe checkout session for subscription
    
    Args:
        plan_name_or_price_id (str): Plan name or Stripe price ID
        customer_email (str): Customer email
        customer_id (str): Existing Stripe customer ID (optional)
        user_id (int): Internal user ID
        success_url (str): Success redirect URL
        cancel_url (str): Cancel redirect URL
    
    Returns:
        str: Checkout session URL
    """
    try:
        from app import db
        
        # Determine price ID from plan name or use direct price ID
        if plan_name_or_price_id in SUBSCRIPTION_PLANS:
            price_id = SUBSCRIPTION_PLANS[plan_name_or_price_id]['stripe_price_id']
            plan_name = plan_name_or_price_id
        else:
            # Assume it's a direct price ID and find the plan
            price_id = plan_name_or_price_id
            plan_name = None
            for name, plan in SUBSCRIPTION_PLANS.items():
                if plan['stripe_price_id'] == price_id:
                    plan_name = name
                    break
        
        # Set default URLs
        domain = os.environ.get('REPLIT_DEV_DOMAIN')
        if not domain:
            domain = os.environ.get('REPLIT_DOMAINS', '').split(',')[0] if os.environ.get('REPLIT_DOMAINS') else 'localhost:5000'
        
        if not success_url:
            success_url = f'https://{domain}/subscription?success=true&plan={plan_name}'
        if not cancel_url:
            cancel_url = f'https://{domain}/subscription?canceled=true'
        
        # Handle free plan (no payment required)
        if plan_name == 'free':
            # For free plan, just update user directly
            if user_id:
                user = User.query.get(user_id)
                if user:
                    user.subscription_tier = 'free'
                    user.subscription_status = 'active'
                    user.proposal_quota = SUBSCRIPTION_PLANS['free']['proposal_quota']
                    db.session.commit()
            return success_url
        
        session_params = {
            'payment_method_types': ['card'],
            'line_items': [{
                'price': price_id,
                'quantity': 1,
            }],
            'mode': 'subscription',
            'success_url': success_url + '?session_id={CHECKOUT_SESSION_ID}',
            'cancel_url': cancel_url,
            'automatic_tax': {'enabled': True},
        }
        
        # Use existing customer or create new one
        if customer_id:
            session_params['customer'] = customer_id
        else:
            session_params['customer_email'] = customer_email
        
        # Create the session
        session = stripe.checkout.Session.create(**session_params)
        
        current_app.logger.info(f"Created checkout session {session.id} for user {user_id}")
        return session.url
        
    except Exception as e:
        current_app.logger.error(f"Error creating checkout session: {str(e)}")
        raise Exception(f"Failed to create checkout session: {str(e)}")

def handle_webhook_event(payload, signature, webhook_secret):
    """
    Handle Stripe webhook events with signature verification
    
    Args:
        payload (str): Raw request payload
        signature (str): Stripe signature header
        webhook_secret (str): Webhook endpoint secret
    
    Returns:
        bool: Success status
    """
    try:
        # Verify webhook signature
        try:
            event = stripe.Webhook.construct_event(
                payload, signature, webhook_secret
            )
        except ValueError as e:
            logging.error(f"Invalid payload: {e}")
            return False
        except stripe.error.SignatureVerificationError as e:
            logging.error(f"Invalid signature: {e}")
            return False
        
        event_type = event['type']
        current_app.logger.info(f"Processing Stripe webhook: {event_type}")
        
        if event_type == 'checkout.session.completed':
            return handle_checkout_completed(event['data']['object'])
        
        elif event_type == 'invoice.payment_succeeded':
            return handle_payment_succeeded(event['data']['object'])
        
        elif event_type == 'invoice.payment_failed':
            return handle_payment_failed(event['data']['object'])
        
        elif event_type == 'customer.subscription.updated':
            return handle_subscription_updated(event['data']['object'])
        
        elif event_type == 'customer.subscription.deleted':
            return handle_subscription_deleted(event['data']['object'])
        
        else:
            current_app.logger.info(f"Unhandled webhook event type: {event_type}")
            return True
            
    except Exception as e:
        current_app.logger.error(f"Error handling webhook event: {str(e)}")
        return False

def handle_checkout_completed(session):
    """Handle successful checkout completion"""
    try:
        user_id = session.get('metadata', {}).get('user_id')
        customer_id = session.get('customer')
        subscription_id = session.get('subscription')
        
        if not user_id:
            current_app.logger.warning("No user_id in checkout session metadata")
            return True
        
        user = User.query.get(int(user_id))
        if not user:
            current_app.logger.error(f"User {user_id} not found for completed checkout")
            return False
        
        # Update user with Stripe customer ID
        user.stripe_customer_id = customer_id
        
        # Get subscription details
        if subscription_id:
            subscription = stripe.Subscription.retrieve(subscription_id)
            price_id = subscription['items']['data'][0]['price']['id']
            
            # Update user subscription based on price ID
            plan = SubscriptionPlan.query.filter_by(stripe_price_id=price_id).first()
            if plan:
                user.subscription_tier = plan.name
                user.subscription_status = 'active'
                user.proposal_quota = plan.proposal_quota
                user.proposals_used = 0  # Reset usage on new subscription
        
        db.session.commit()
        current_app.logger.info(f"Updated user {user_id} subscription after checkout")
        return True
        
    except Exception as e:
        current_app.logger.error(f"Error handling checkout completion: {str(e)}")
        db.session.rollback()
        return False

def handle_payment_succeeded(invoice):
    """Handle successful payment"""
    try:
        customer_id = invoice.get('customer')
        subscription_id = invoice.get('subscription')
        
        if not customer_id:
            return True
        
        user = User.query.filter_by(stripe_customer_id=customer_id).first()
        if not user:
            current_app.logger.warning(f"User not found for customer {customer_id}")
            return True
        
        # Update subscription status
        user.subscription_status = 'active'
        
        # Reset monthly quota on successful payment
        if subscription_id:
            user.proposals_used = 0
        
        db.session.commit()
        current_app.logger.info(f"Payment succeeded for user {user.id}")
        return True
        
    except Exception as e:
        current_app.logger.error(f"Error handling payment success: {str(e)}")
        db.session.rollback()
        return False

def handle_payment_failed(invoice):
    """Handle failed payment"""
    try:
        customer_id = invoice.get('customer')
        
        if not customer_id:
            return True
        
        user = User.query.filter_by(stripe_customer_id=customer_id).first()
        if not user:
            current_app.logger.warning(f"User not found for customer {customer_id}")
            return True
        
        # Update subscription status
        user.subscription_status = 'past_due'
        
        db.session.commit()
        current_app.logger.info(f"Payment failed for user {user.id}")
        return True
        
    except Exception as e:
        current_app.logger.error(f"Error handling payment failure: {str(e)}")
        db.session.rollback()
        return False

def handle_subscription_updated(subscription):
    """Handle subscription updates"""
    try:
        customer_id = subscription.get('customer')
        status = subscription.get('status')
        
        if not customer_id:
            return True
        
        user = User.query.filter_by(stripe_customer_id=customer_id).first()
        if not user:
            current_app.logger.warning(f"User not found for customer {customer_id}")
            return True
        
        # Update subscription status
        user.subscription_status = status
        
        # Update quota based on new plan if changed
        if subscription.get('items', {}).get('data'):
            price_id = subscription['items']['data'][0]['price']['id']
            plan = SubscriptionPlan.query.filter_by(stripe_price_id=price_id).first()
            if plan:
                user.subscription_tier = plan.name
                user.proposal_quota = plan.proposal_quota
        
        db.session.commit()
        current_app.logger.info(f"Subscription updated for user {user.id}")
        return True
        
    except Exception as e:
        current_app.logger.error(f"Error handling subscription update: {str(e)}")
        db.session.rollback()
        return False

def handle_subscription_deleted(subscription):
    """Handle subscription cancellation"""
    try:
        customer_id = subscription.get('customer')
        
        if not customer_id:
            return True
        
        user = User.query.filter_by(stripe_customer_id=customer_id).first()
        if not user:
            current_app.logger.warning(f"User not found for customer {customer_id}")
            return True
        
        # Update user to free tier
        user.subscription_status = 'canceled'
        user.subscription_tier = 'free'
        user.proposal_quota = 3  # Free tier quota
        
        db.session.commit()
        current_app.logger.info(f"Subscription canceled for user {user.id}")
        return True
        
    except Exception as e:
        current_app.logger.error(f"Error handling subscription deletion: {str(e)}")
        db.session.rollback()
        return False

def get_customer_subscriptions(customer_id):
    """Get active subscriptions for a customer"""
    try:
        subscriptions = stripe.Subscription.list(
            customer=customer_id,
            status='active'
        )
        return subscriptions.data
        
    except Exception as e:
        current_app.logger.error(f"Error fetching customer subscriptions: {str(e)}")
        return []
