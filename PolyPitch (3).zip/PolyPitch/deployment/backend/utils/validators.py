import re
from flask import current_app

def validate_email(email):
    """
    Validate email format
    
    Args:
        email (str): Email address to validate
    
    Returns:
        bool: True if valid email format
    """
    if not email or not isinstance(email, str):
        return False
    
    email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(email_pattern, email.strip()))

def validate_password(password):
    """
    Validate password strength
    
    Args:
        password (str): Password to validate
    
    Returns:
        bool: True if password meets requirements
    """
    if not password or not isinstance(password, str):
        return False
    
    # At least 8 characters
    if len(password) < 8:
        return False
    
    return True

def validate_proposal_request(data):
    """
    Validate proposal generation request data
    
    Args:
        data (dict): Request data
    
    Returns:
        str: Error message if invalid, None if valid
    """
    if not data or not isinstance(data, dict):
        return "Invalid request data"
    
    required_fields = ['title', 'target_country', 'target_language', 'product_description']
    
    for field in required_fields:
        if field not in data or not data[field] or not data[field].strip():
            return f"Missing required field: {field}"
    
    # Validate field lengths
    if len(data['title'].strip()) > 200:
        return "Title must be 200 characters or less"
    
    if len(data['product_description'].strip()) < 10:
        return "Product description must be at least 10 characters long"
    
    if len(data['product_description'].strip()) > 5000:
        return "Product description must be 5000 characters or less"
    
    # Validate target country
    valid_countries = [
        'United States', 'Canada', 'United Kingdom', 'Germany', 'France', 
        'Spain', 'Italy', 'Netherlands', 'Belgium', 'Switzerland', 
        'Austria', 'Sweden', 'Norway', 'Denmark', 'Finland', 
        'Japan', 'South Korea', 'China', 'Australia', 'New Zealand',
        'Brazil', 'Mexico', 'Argentina', 'India', 'Singapore'
    ]
    
    if data['target_country'] not in valid_countries:
        return f"Unsupported target country: {data['target_country']}"
    
    # Validate target language
    valid_languages = [
        'English', 'Spanish', 'French', 'German', 'Italian', 'Portuguese',
        'Dutch', 'Swedish', 'Norwegian', 'Danish', 'Finnish',
        'Japanese', 'Korean', 'Chinese (Simplified)', 'Chinese (Traditional)',
        'Hindi', 'Arabic'
    ]
    
    if data['target_language'] not in valid_languages:
        return f"Unsupported target language: {data['target_language']}"
    
    # Validate optional fields
    if 'company_info' in data and data['company_info'] and len(data['company_info']) > 2000:
        return "Company information must be 2000 characters or less"
    
    if 'target_audience' in data and data['target_audience'] and len(data['target_audience']) > 1000:
        return "Target audience description must be 1000 characters or less"
    
    return None

def validate_stripe_price_id(price_id):
    """
    Validate Stripe price ID format
    
    Args:
        price_id (str): Stripe price ID
    
    Returns:
        bool: True if valid format
    """
    if not price_id or not isinstance(price_id, str):
        return False
    
    # Stripe price IDs start with 'price_'
    return price_id.startswith('price_') and len(price_id) > 6

def sanitize_input(text, max_length=None):
    """
    Sanitize user input text
    
    Args:
        text (str): Input text to sanitize
        max_length (int): Maximum allowed length
    
    Returns:
        str: Sanitized text
    """
    if not text or not isinstance(text, str):
        return ""
    
    # Remove leading/trailing whitespace
    sanitized = text.strip()
    
    # Remove any potential script tags or HTML
    sanitized = re.sub(r'<[^>]*>', '', sanitized)
    
    # Limit length if specified
    if max_length and len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
    
    return sanitized

def validate_pagination_params(page, per_page):
    """
    Validate pagination parameters
    
    Args:
        page (int): Page number
        per_page (int): Items per page
    
    Returns:
        tuple: (validated_page, validated_per_page, error_message)
    """
    try:
        page = int(page) if page else 1
        per_page = int(per_page) if per_page else 10
        
        if page < 1:
            page = 1
        
        if per_page < 1:
            per_page = 10
        elif per_page > 100:
            per_page = 100
        
        return page, per_page, None
        
    except (ValueError, TypeError):
        return 1, 10, "Invalid pagination parameters"

def validate_search_query(query):
    """
    Validate search query
    
    Args:
        query (str): Search query
    
    Returns:
        str: Error message if invalid, None if valid
    """
    if not query or not isinstance(query, str):
        return "Search query is required"
    
    query = query.strip()
    
    if len(query) < 2:
        return "Search query must be at least 2 characters long"
    
    if len(query) > 100:
        return "Search query must be 100 characters or less"
    
    # Check for potentially malicious patterns
    dangerous_patterns = ['<script', 'javascript:', 'vbscript:', 'onload=', 'onerror=']
    query_lower = query.lower()
    
    for pattern in dangerous_patterns:
        if pattern in query_lower:
            return "Invalid search query"
    
    return None
