import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from './contexts/AuthContext'
import { LanguageProvider } from './contexts/LanguageContext'
import ProtectedRoute from './components/ProtectedRoute'
import Navbar from './components/Navbar'
import DashboardLayout from './components/DashboardLayout'
import HomePage from './pages/HomePage'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import DashboardPage from './pages/DashboardPage'
import ProposalsPage from './pages/ProposalsPage'
import CreateProposalPage from './pages/CreateProposalPage'
import PricingPage from './pages/PricingPage'
import SubscriptionPage from './pages/SubscriptionPage'
import CalendarPage from './pages/CalendarPage'
import ExpensesPage from './pages/ExpensesPage'

function AppContent() {
  const location = useLocation()
  
  // Pages that should use the dashboard layout with sidebar
  const dashboardPages = ['/dashboard', '/proposals', '/create-proposal', '/subscription', '/calendar', '/expenses']
  const isDashboardPage = dashboardPages.includes(location.pathname)
  
  // Pages that shouldn't show the navbar
  const noNavbarPages = ['/login', '/register']
  const showNavbar = !noNavbarPages.includes(location.pathname) && !isDashboardPage

  return (
    <div className="min-h-screen bg-dark-950">
      {showNavbar && <Navbar />}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/proposals" 
          element={
            <ProtectedRoute>
              <DashboardLayout>
                <ProposalsPage />
              </DashboardLayout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/create-proposal" 
          element={
            <ProtectedRoute>
              <DashboardLayout>
                <CreateProposalPage />
              </DashboardLayout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/subscription" 
          element={
            <ProtectedRoute>
              <DashboardLayout>
                <SubscriptionPage />
              </DashboardLayout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/calendar" 
          element={
            <ProtectedRoute>
              <DashboardLayout>
                <CalendarPage />
              </DashboardLayout>
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/expenses" 
          element={
            <ProtectedRoute>
              <DashboardLayout>
                <ExpensesPage />
              </DashboardLayout>
            </ProtectedRoute>
          } 
        />
      </Routes>
      <Toaster 
        position="top-right"
        toastOptions={{
          style: {
            background: '#1e293b',
            color: '#f8fafc',
            border: '1px solid #475569'
          }
        }}
      />
    </div>
  )
}

function App() {
  return (
    <Router>
      <LanguageProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </LanguageProvider>
    </Router>
  )
}

export default App