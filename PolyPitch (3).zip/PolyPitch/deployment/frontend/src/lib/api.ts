import axios from 'axios'
import { AuthResponse, Proposal, CreateProposalRequest, UserQuota, SubscriptionPlan, ApiError } from '../types'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('auth_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('auth_token')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export const authApi = {
  register: async (username: string, email: string, password: string): Promise<AuthResponse> => {
    const response = await api.post('/api/register', { username, email, password })
    return response.data
  },

  login: async (email: string, password: string): Promise<AuthResponse> => {
    const response = await api.post('/api/login', { email, password })
    return response.data
  },

  getProfile: async (): Promise<{ user: any }> => {
    const response = await api.get('/api/profile')
    return response.data
  }
}

export const proposalApi = {
  create: async (data: CreateProposalRequest): Promise<{ success: boolean; proposal_id: number; generated_content: string; quota_remaining: number }> => {
    const response = await api.post('/api/generate-proposal', data)
    return response.data
  },

  getAll: async (page = 1, per_page = 10): Promise<{ proposals: Proposal[]; pagination: any }> => {
    const response = await api.get(`/api/proposals?page=${page}&per_page=${per_page}`)
    return response.data
  },

  getById: async (id: number): Promise<Proposal> => {
    const response = await api.get(`/api/proposals/${id}`)
    return response.data
  }
}

export const subscriptionApi = {
  getUserQuota: async (): Promise<UserQuota> => {
    const response = await api.get('/api/user/quota')
    return response.data
  },

  getPlans: async (): Promise<{ plans: SubscriptionPlan[] }> => {
    const response = await api.get('/stripe/plans')
    return response.data
  },

  createCheckoutSession: async (priceId: string): Promise<{ success: boolean; checkout_url: string }> => {
    const response = await api.post('/stripe/create-checkout-session', { price_id: priceId })
    return response.data
  },

  createPortalSession: async (): Promise<{ success: boolean; portal_url: string }> => {
    const response = await api.post('/stripe/portal')
    return response.data
  }
}

// Calendar API
export const calendarApi = {
  getCalendar: async () => {
    const response = await api.get('/calendar')
    return response.data
  },

  updateCalendar: async (data: any) => {
    const response = await api.put('/calendar', data)
    return response.data
  },

  getAppointments: async (params: any = {}) => {
    const queryParams = new URLSearchParams(params)
    const response = await api.get(`/appointments?${queryParams}`)
    return response.data
  },

  createAppointment: async (data: any) => {
    const response = await api.post('/appointments', data)
    return response.data
  },

  getAppointment: async (id: number) => {
    const response = await api.get(`/appointments/${id}`)
    return response.data
  },

  updateAppointment: async (id: number, data: any) => {
    const response = await api.put(`/appointments/${id}`, data)
    return response.data
  },

  deleteAppointment: async (id: number) => {
    const response = await api.delete(`/appointments/${id}`)
    return response.data
  },

  suggestTime: async (data: any) => {
    const response = await api.post('/appointments/suggest-time', data)
    return response.data
  },

  checkAvailability: async (startDate: string, endDate: string) => {
    const response = await api.get(`/appointments/availability?start_date=${startDate}&end_date=${endDate}`)
    return response.data
  }
}

// Expense API
export const expenseApi = {
  getExpenses: async (params: any = {}) => {
    const queryParams = new URLSearchParams(params)
    const response = await api.get(`/expenses?${queryParams}`)
    return response.data
  },

  createExpense: async (data: any) => {
    const response = await api.post('/expenses', data)
    return response.data
  },

  getExpense: async (id: number) => {
    const response = await api.get(`/expenses/${id}`)
    return response.data
  },

  updateExpense: async (id: number, data: any) => {
    const response = await api.put(`/expenses/${id}`, data)
    return response.data
  },

  deleteExpense: async (id: number) => {
    const response = await api.delete(`/expenses/${id}`)
    return response.data
  },

  getSummary: async (month?: number, year?: number) => {
    const params = new URLSearchParams()
    if (month) params.append('month', month.toString())
    if (year) params.append('year', year.toString())
    const response = await api.get(`/expenses/summary?${params}`)
    return response.data
  },

  getCategories: async () => {
    const response = await api.get('/expenses/categories')
    return response.data
  },

  createCategory: async (data: any) => {
    const response = await api.post('/expenses/categories', data)
    return response.data
  },

  analyzeExpenses: async (month?: number, year?: number) => {
    const response = await api.post('/expenses/analyze', { month, year })
    return response.data
  },

  exportExpenses: async (startDate?: string, endDate?: string) => {
    const params = new URLSearchParams()
    if (startDate) params.append('start_date', startDate)
    if (endDate) params.append('end_date', endDate)
    const response = await api.get(`/expenses/export?${params}`)
    return response.data
  }
}

export default api