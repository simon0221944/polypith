import { Link } from 'react-router-dom'
import { Brain, Globe, CreditCard, ArrowRight, Sparkles } from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'
import { useAuth } from '../contexts/AuthContext'

export default function HomePage() {
  const { t } = useLanguage()
  const { user } = useAuth()

  return (
    <div className="min-h-screen bg-dark-950">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-500/20 via-dark-950 to-dark-950"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-24">
          <div className="text-center">
            <div className="mb-8">
              <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary-500/10 border border-primary-500/20 mb-6">
                <Sparkles className="h-4 w-4 text-primary-400 mr-2" />
                <span className="text-primary-400 text-sm font-medium">AI-Powered SaaS Platform</span>
              </div>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              <span className="gradient-text">{t('home.title')}</span>
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              {t('home.subtitle')}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to={user ? "/dashboard" : "/register"}
                className="btn-primary text-lg px-8 py-3 inline-flex items-center justify-center"
              >
                {t('home.getStarted')}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/pricing"
                className="btn-secondary text-lg px-8 py-3 inline-flex items-center justify-center"
              >
                {t('home.learnMore')}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-dark-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              {t('home.features.title')}
            </h2>
            <p className="text-xl text-gray-400">
              {t('home.features.subtitle')}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="card group hover:border-primary-500/50 transition-all duration-300">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-500/10 rounded-lg mb-6 group-hover:bg-primary-500/20 transition-colors">
                  <Brain className="h-8 w-8 text-primary-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">
                  {t('home.features.ai.title')}
                </h3>
                <p className="text-gray-400">
                  {t('home.features.ai.description')}
                </p>
              </div>
            </div>

            <div className="card group hover:border-primary-500/50 transition-all duration-300">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500/10 rounded-lg mb-6 group-hover:bg-green-500/20 transition-colors">
                  <Globe className="h-8 w-8 text-green-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">
                  {t('home.features.multilingual.title')}
                </h3>
                <p className="text-gray-400">
                  {t('home.features.multilingual.description')}
                </p>
              </div>
            </div>

            <div className="card group hover:border-primary-500/50 transition-all duration-300">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-500/10 rounded-lg mb-6 group-hover:bg-blue-500/20 transition-colors">
                  <CreditCard className="h-8 w-8 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">
                  {t('home.features.billing.title')}
                </h3>
                <p className="text-gray-400">
                  {t('home.features.billing.description')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Transform Your Global Sales?
          </h2>
          <p className="text-xl text-gray-400 mb-8">
            Join thousands of businesses using PolyPitch to create winning proposals in any language.
          </p>
          <Link
            to={user ? "/dashboard" : "/register"}
            className="btn-primary text-lg px-8 py-3 inline-flex items-center"
          >
            {t('home.getStarted')}
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  )
}