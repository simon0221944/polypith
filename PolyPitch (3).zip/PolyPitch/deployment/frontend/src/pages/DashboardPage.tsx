import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus, FileText, CreditCard, BarChart3, Calendar, Globe, DollarSign, Clock, TrendingUp, Users, Star } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { useLanguage } from '../contexts/LanguageContext'
import { subscriptionApi, proposalApi } from '../lib/api'
import { UserQuota, Proposal } from '../types'
import { formatDate, getSubscriptionBadgeColor, capitalizeFirst } from '../lib/utils'
import DashboardLayout from '../components/DashboardLayout'

export default function DashboardPage() {
  const { user } = useAuth()
  const { t } = useLanguage()
  const [quota, setQuota] = useState<UserQuota | null>(null)
  const [recentProposals, setRecentProposals] = useState<Proposal[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [quotaData, proposalsData] = await Promise.all([
          subscriptionApi.getUserQuota(),
          proposalApi.getAll(1, 5)
        ])
        
        setQuota(quotaData)
        setRecentProposals(proposalsData.proposals)
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchDashboardData()
  }, [])

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
        </div>
      </DashboardLayout>
    )
  }

  const quotaPercentage = quota ? (quota.proposals_used / quota.proposal_quota) * 100 : 0

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Welcome Header */}
        <div className="bg-gradient-to-r from-primary-500/10 to-primary-600/10 border border-primary-500/20 rounded-2xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white mb-2">
                Welcome back, {user?.username || 'User'}!
              </h1>
              <p className="text-gray-400">
                {quota && `You have ${quota.proposal_quota - quota.proposals_used} proposals remaining this month`}
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Link
                to="/create-proposal"
                className="bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-600 hover:to-primary-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-primary-500/25 flex items-center"
              >
                <Plus className="h-5 w-5 mr-2" />
                New Proposal
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-xl p-6 hover:border-primary-500/20 transition-all duration-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Proposals Used</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {quota?.proposals_used || 0}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  of {quota?.proposal_quota || 0} available
                </p>
              </div>
              <div className="p-3 bg-primary-500/10 rounded-lg">
                <FileText className="h-6 w-6 text-primary-500" />
              </div>
            </div>
            <div className="mt-4">
              <div className="bg-dark-700 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-primary-500 to-primary-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(quotaPercentage, 100)}%` }}
                ></div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-xl p-6 hover:border-green-500/20 transition-all duration-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Subscription</p>
                <p className="text-2xl font-bold text-white mt-1 capitalize">
                  {quota?.subscription_tier || 'Free'}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  {quota?.subscription_status === 'active' ? 'Active' : 'Inactive'}
                </p>
              </div>
              <div className="p-3 bg-green-500/10 rounded-lg">
                <CreditCard className="h-6 w-6 text-green-500" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-xl p-6 hover:border-blue-500/20 transition-all duration-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Recent Proposals</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {recentProposals.length}
                </p>
                <p className="text-xs text-gray-500 mt-1">Last 5 created</p>
              </div>
              <div className="p-3 bg-blue-500/10 rounded-lg">
                <BarChart3 className="h-6 w-6 text-blue-500" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-xl p-6 hover:border-purple-500/20 transition-all duration-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">Languages</p>
                <p className="text-2xl font-bold text-white mt-1">50+</p>
                <p className="text-xs text-gray-500 mt-1">Supported</p>
              </div>
              <div className="p-3 bg-purple-500/10 rounded-lg">
                <Globe className="h-6 w-6 text-purple-500" />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link
            to="/create-proposal"
            className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-xl p-6 hover:border-primary-500/50 transition-all duration-300 group"
          >
            <div className="flex items-center mb-4">
              <div className="p-3 bg-primary-500/10 rounded-lg group-hover:bg-primary-500/20 transition-colors">
                <Plus className="h-6 w-6 text-primary-500" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-white">Create Proposal</h3>
                <p className="text-gray-400 text-sm">Generate AI-powered proposals</p>
              </div>
            </div>
          </Link>

          <Link
            to="/calendar"
            className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-xl p-6 hover:border-blue-500/50 transition-all duration-300 group"
          >
            <div className="flex items-center mb-4">
              <div className="p-3 bg-blue-500/10 rounded-lg group-hover:bg-blue-500/20 transition-colors">
                <Calendar className="h-6 w-6 text-blue-500" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-white">Schedule Meeting</h3>
                <p className="text-gray-400 text-sm">Manage appointments</p>
              </div>
            </div>
          </Link>

          <Link
            to="/expenses"
            className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-xl p-6 hover:border-green-500/50 transition-all duration-300 group"
          >
            <div className="flex items-center mb-4">
              <div className="p-3 bg-green-500/10 rounded-lg group-hover:bg-green-500/20 transition-colors">
                <DollarSign className="h-6 w-6 text-green-500" />
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-white">Track Expenses</h3>
                <p className="text-gray-400 text-sm">Monitor business costs</p>
              </div>
            </div>
          </Link>
        </div>

        {/* Recent Proposals */}
        {recentProposals.length > 0 && (
          <div className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">Recent Proposals</h2>
              <Link
                to="/proposals"
                className="text-primary-500 hover:text-primary-400 text-sm font-medium"
              >
                View all →
              </Link>
            </div>
            
            <div className="space-y-4">
              {recentProposals.map((proposal) => (
                <div
                  key={proposal.id}
                  className="bg-dark-800/50 border border-dark-600/50 rounded-lg p-4 hover:border-primary-500/20 transition-all duration-300"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-white font-medium mb-1">{proposal.title}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-400">
                        <span className="flex items-center">
                          <Globe className="h-4 w-4 mr-1" />
                          {proposal.target_country}
                        </span>
                        <span className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {formatDate(proposal.created_at)}
                        </span>
                      </div>
                    </div>
                    <span className="bg-primary-500/10 text-primary-400 px-3 py-1 rounded-full text-xs font-medium">
                      {proposal.target_language}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}