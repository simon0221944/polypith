import { useEffect, useState } from 'react'
import { CreditCard, Check, Crown, Zap, Star, Users, Globe, TrendingUp, Shield } from 'lucide-react'
import { subscriptionApi } from '../lib/api'
import { SubscriptionPlan, UserQuota } from '../types'
import { formatCurrency } from '../lib/utils'
import Card from '../components/ui/Card'
import toast from 'react-hot-toast'

export default function SubscriptionPage() {
  const [plans, setPlans] = useState<SubscriptionPlan[]>([])
  const [userQuota, setUserQuota] = useState<UserQuota | null>(null)
  const [loading, setLoading] = useState(true)
  const [processingPlan, setProcessingPlan] = useState<string | null>(null)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [plansData, quotaData] = await Promise.all([
        subscriptionApi.getPlans(),
        subscriptionApi.getUserQuota()
      ])
      
      setPlans(plansData.plans || [])
      setUserQuota(quotaData)
    } catch (error) {
      toast.error('Failed to load subscription data')
    } finally {
      setLoading(false)
    }
  }

  const handleSubscribe = async (priceId: string, planName: string) => {
    try {
      setProcessingPlan(priceId)
      const response = await subscriptionApi.createCheckoutSession(priceId)
      
      if (response.success && response.checkout_url) {
        window.location.href = response.checkout_url
      } else {
        toast.error('Failed to create checkout session')
      }
    } catch (error) {
      toast.error('Failed to start subscription process')
    } finally {
      setProcessingPlan(null)
    }
  }

  const handleManageSubscription = async () => {
    try {
      const response = await subscriptionApi.createPortalSession()
      
      if (response.success && response.portal_url) {
        window.location.href = response.portal_url
      } else {
        toast.error('Failed to access billing portal')
      }
    } catch (error) {
      toast.error('Failed to open billing portal')
    }
  }

  const getPlanIcon = (planName: string) => {
    switch (planName.toLowerCase()) {
      case 'free':
        return <Star className="h-8 w-8 text-gray-400" />
      case 'basic':
        return <Zap className="h-8 w-8 text-blue-500" />
      case 'pro':
        return <Crown className="h-8 w-8 text-primary-500" />
      case 'enterprise':
        return <Shield className="h-8 w-8 text-purple-500" />
      default:
        return <CreditCard className="h-8 w-8 text-gray-400" />
    }
  }

  const getPlanColor = (planName: string) => {
    switch (planName.toLowerCase()) {
      case 'free':
        return 'border-gray-500/20 hover:border-gray-500/50'
      case 'basic':
        return 'border-blue-500/20 hover:border-blue-500/50'
      case 'pro':
        return 'border-primary-500/20 hover:border-primary-500/50'
      case 'enterprise':
        return 'border-purple-500/20 hover:border-purple-500/50'
      default:
        return 'border-gray-500/20 hover:border-gray-500/50'
    }
  }

  const getCurrentPlan = () => {
    return plans.find(plan => plan.name.toLowerCase() === userQuota?.subscription_tier?.toLowerCase())
  }

  const getFeaturesList = (planName: string) => {
    const baseFeatures = [
      'AI-powered proposal generation',
      'Multilingual support',
      'Basic templates',
      'Email support'
    ]

    switch (planName.toLowerCase()) {
      case 'free':
        return [
          '3 proposals per month',
          ...baseFeatures.slice(0, 2),
          'Basic templates',
          'Community support'
        ]
      case 'basic':
        return [
          '25 proposals per month',
          ...baseFeatures,
          'Priority email support',
          'Advanced templates',
          'Calendar integration'
        ]
      case 'pro':
        return [
          '100 proposals per month',
          ...baseFeatures,
          'Priority support',
          'Advanced templates',
          'Calendar & expense tracking',
          'Analytics dashboard',
          'Custom branding'
        ]
      case 'enterprise':
        return [
          'Unlimited proposals',
          ...baseFeatures,
          '24/7 phone support',
          'Custom templates',
          'Full platform access',
          'Advanced analytics',
          'White-label solution',
          'API access',
          'Dedicated account manager'
        ]
      default:
        return baseFeatures
    }
  }

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="animate-pulse">
          <div className="h-8 bg-dark-800 rounded w-64 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-dark-800 rounded-xl h-96"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const currentPlan = getCurrentPlan()

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary-500/10 to-primary-600/10 border border-primary-500/20 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-gradient-to-r from-primary-500 to-primary-600 rounded-xl">
              <CreditCard className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Subscription Plans</h1>
              <p className="text-gray-400">Choose the perfect plan for your business needs</p>
            </div>
          </div>
          {userQuota?.subscription_status === 'active' && (
            <button
              onClick={handleManageSubscription}
              className="bg-dark-800 hover:bg-dark-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 border border-dark-600"
            >
              Manage Billing
            </button>
          )}
        </div>
      </div>

      {/* Current Plan Status */}
      {userQuota && (
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Current Plan</h3>
              <div className="flex items-center space-x-3">
                <span className="text-2xl font-bold text-primary-400 capitalize">
                  {userQuota.subscription_tier}
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  userQuota.subscription_status === 'active' 
                    ? 'bg-green-500/10 text-green-400' 
                    : 'bg-gray-500/10 text-gray-400'
                }`}>
                  {userQuota.subscription_status}
                </span>
              </div>
              <p className="text-gray-400 mt-2">
                {userQuota.proposals_used} of {userQuota.proposal_quota} proposals used this month
              </p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-white">
                {currentPlan ? formatCurrency(currentPlan.price, currentPlan.currency) : 'Free'}
              </div>
              <div className="text-sm text-gray-400">
                {currentPlan && currentPlan.price > 0 ? '/month' : ''}
              </div>
            </div>
          </div>
          
          {/* Usage Progress */}
          <div className="mt-6">
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span>Monthly Usage</span>
              <span>{Math.round((userQuota.proposals_used / userQuota.proposal_quota) * 100)}%</span>
            </div>
            <div className="w-full bg-dark-800 rounded-full h-3">
              <div
                className="bg-gradient-to-r from-primary-500 to-primary-600 h-3 rounded-full transition-all duration-500"
                style={{ width: `${Math.min((userQuota.proposals_used / userQuota.proposal_quota) * 100, 100)}%` }}
              ></div>
            </div>
          </div>
        </Card>
      )}

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan) => {
          const isCurrentPlan = plan.name.toLowerCase() === userQuota?.subscription_tier?.toLowerCase()
          const isPopular = plan.name.toLowerCase() === 'pro'
          
          return (
            <Card 
              key={plan.id} 
              className={`relative ${getPlanColor(plan.name)} transition-all duration-300 ${
                isCurrentPlan ? 'ring-2 ring-primary-500/50' : ''
              }`}
            >
              {isPopular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-to-r from-primary-500 to-primary-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="p-6 space-y-6">
                {/* Plan Header */}
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    {getPlanIcon(plan.name)}
                  </div>
                  <h3 className="text-xl font-semibold text-white capitalize mb-2">
                    {plan.name}
                  </h3>
                  <div className="text-center">
                    <span className="text-3xl font-bold text-white">
                      {formatCurrency(plan.price, plan.currency)}
                    </span>
                    {plan.price > 0 && (
                      <span className="text-gray-400">/month</span>
                    )}
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-3">
                  {getFeaturesList(plan.name).map((feature, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-300 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Action Button */}
                <div className="pt-4">
                  {isCurrentPlan ? (
                    <button 
                      disabled
                      className="w-full bg-dark-700 text-gray-400 py-3 px-4 rounded-lg font-medium cursor-not-allowed"
                    >
                      Current Plan
                    </button>
                  ) : plan.name.toLowerCase() === 'free' ? (
                    <button 
                      disabled
                      className="w-full bg-dark-700 text-gray-400 py-3 px-4 rounded-lg font-medium cursor-not-allowed"
                    >
                      Downgrade to Free
                    </button>
                  ) : (
                    <button
                      onClick={() => handleSubscribe(plan.stripe_price_id, plan.name)}
                      disabled={processingPlan === plan.stripe_price_id}
                      className={`w-full py-3 px-4 rounded-lg font-medium transition-all duration-300 ${
                        isPopular
                          ? 'bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-600 hover:to-primary-700 text-white shadow-lg hover:shadow-primary-500/25'
                          : 'bg-dark-800 hover:bg-dark-700 text-white border border-dark-600'
                      }`}
                    >
                      {processingPlan === plan.stripe_price_id ? (
                        <div className="flex items-center justify-center">
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                          Processing...
                        </div>
                      ) : (
                        `Upgrade to ${plan.name}`
                      )}
                    </button>
                  )}
                </div>
              </div>
            </Card>
          )
        })}
      </div>

      {/* FAQ Section */}
      <Card className="p-8">
        <h3 className="text-2xl font-semibold text-white mb-6">Frequently Asked Questions</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <h4 className="text-lg font-medium text-white mb-2">Can I change my plan anytime?</h4>
              <p className="text-gray-400">
                Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately, 
                and you'll be charged or credited on a pro-rated basis.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-medium text-white mb-2">What happens if I exceed my quota?</h4>
              <p className="text-gray-400">
                When you reach your monthly proposal limit, you'll need to upgrade your plan or wait 
                for the next billing cycle to generate more proposals.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-medium text-white mb-2">Is there a free trial?</h4>
              <p className="text-gray-400">
                Yes! Every new account starts with our Free plan, which includes 3 proposals per month 
                so you can test our AI-powered proposal generation.
              </p>
            </div>
          </div>
          
          <div className="space-y-6">
            <div>
              <h4 className="text-lg font-medium text-white mb-2">What payment methods do you accept?</h4>
              <p className="text-gray-400">
                We accept all major credit cards (Visa, MasterCard, American Express) and bank transfers 
                through our secure Stripe payment processing.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-medium text-white mb-2">Do you offer refunds?</h4>
              <p className="text-gray-400">
                We offer a 30-day money-back guarantee for all paid plans. If you're not satisfied, 
                contact our support team for a full refund.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-medium text-white mb-2">Need help choosing a plan?</h4>
              <p className="text-gray-400">
                Our team is here to help! Contact us at support@polypitch.com or use the chat widget 
                to speak with our sales team about your specific needs.
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Enterprise CTA */}
      <Card className="p-8 bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/20">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-purple-500/20 rounded-xl">
              <Users className="h-12 w-12 text-purple-400" />
            </div>
          </div>
          <h3 className="text-2xl font-semibold text-white mb-4">Need a Custom Solution?</h3>
          <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
            Large teams and enterprises require specialized features. Our Enterprise plan includes 
            custom integrations, dedicated support, and volume pricing tailored to your organization.
          </p>
          <button className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white px-8 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-purple-500/25">
            Contact Sales
          </button>
        </div>
      </Card>
    </div>
  )
}