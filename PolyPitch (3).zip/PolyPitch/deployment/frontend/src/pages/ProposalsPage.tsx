import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { FileText, Plus, Globe, Calendar, Eye, Search, Filter, ChevronDown } from 'lucide-react'
import { proposalApi } from '../lib/api'
import { Proposal } from '../types'
import { formatDate } from '../lib/utils'
import Card from '../components/ui/Card'
import toast from 'react-hot-toast'

export default function ProposalsPage() {
  const [proposals, setProposals] = useState<Proposal[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCountry, setFilterCountry] = useState('')
  const [filterLanguage, setFilterLanguage] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  useEffect(() => {
    fetchProposals()
  }, [currentPage])

  const fetchProposals = async () => {
    try {
      setLoading(true)
      const response = await proposalApi.getAll(currentPage, 12)
      setProposals(response.proposals)
      setTotalPages(response.pagination?.total_pages || 1)
    } catch (error) {
      toast.error('Failed to load proposals')
    } finally {
      setLoading(false)
    }
  }

  const filteredProposals = proposals.filter(proposal => {
    const matchesSearch = proposal.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         proposal.product_description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCountry = !filterCountry || proposal.target_country === filterCountry
    const matchesLanguage = !filterLanguage || proposal.target_language === filterLanguage
    
    return matchesSearch && matchesCountry && matchesLanguage
  })

  const uniqueCountries = [...new Set(proposals.map(p => p.target_country))]
  const uniqueLanguages = [...new Set(proposals.map(p => p.target_language))]

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="animate-pulse">
          <div className="h-8 bg-dark-800 rounded w-64 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-dark-800 rounded-xl h-64"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary-500/10 to-primary-600/10 border border-primary-500/20 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-gradient-to-r from-primary-500 to-primary-600 rounded-xl">
              <FileText className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">My Proposals</h1>
              <p className="text-gray-400">Manage your AI-generated sales proposals</p>
            </div>
          </div>
          <Link
            to="/create-proposal"
            className="bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-600 hover:to-primary-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-primary-500/25 flex items-center"
          >
            <Plus className="h-5 w-5 mr-2" />
            New Proposal
          </Link>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-gradient-to-br from-dark-900 to-dark-800 border border-dark-700 rounded-xl p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search proposals..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 pl-10 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500/50 transition-all duration-300"
            />
          </div>

          <select
            value={filterCountry}
            onChange={(e) => setFilterCountry(e.target.value)}
            className="bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500/50 transition-all duration-300"
          >
            <option value="">All Countries</option>
            {uniqueCountries.map(country => (
              <option key={country} value={country}>{country}</option>
            ))}
          </select>

          <select
            value={filterLanguage}
            onChange={(e) => setFilterLanguage(e.target.value)}
            className="bg-dark-800/50 border border-dark-600/50 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500/50 transition-all duration-300"
          >
            <option value="">All Languages</option>
            {uniqueLanguages.map(language => (
              <option key={language} value={language}>{language}</option>
            ))}
          </select>

          <button
            onClick={() => {
              setSearchTerm('')
              setFilterCountry('')
              setFilterLanguage('')
            }}
            className="bg-dark-800/50 border border-dark-600/50 text-gray-400 hover:text-white rounded-lg px-4 py-3 transition-colors duration-300"
          >
            Clear Filters
          </button>
        </div>
      </div>

      {/* Proposals Grid */}
      {filteredProposals.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProposals.map((proposal) => (
            <Card key={proposal.id} className="hover:border-primary-500/50 transition-all duration-300 group">
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <h3 className="text-lg font-semibold text-white group-hover:text-primary-400 transition-colors">
                    {proposal.title}
                  </h3>
                  <Link
                    to={`/proposals/${proposal.id}`}
                    className="p-2 bg-dark-800 hover:bg-primary-500/20 rounded-lg transition-colors duration-300"
                  >
                    <Eye className="h-4 w-4 text-gray-400 hover:text-primary-400" />
                  </Link>
                </div>

                <p className="text-gray-400 text-sm line-clamp-3">
                  {proposal.product_description}
                </p>

                <div className="flex items-center space-x-3 text-xs">
                  <span className="flex items-center bg-dark-700 px-3 py-1 rounded-full">
                    <Globe className="h-3 w-3 mr-1" />
                    {proposal.target_country}
                  </span>
                  <span className="bg-primary-500/10 text-primary-400 px-3 py-1 rounded-full">
                    {proposal.target_language}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-dark-700/50">
                  <span className="flex items-center text-xs text-gray-500">
                    <Calendar className="h-3 w-3 mr-1" />
                    {formatDate(proposal.created_at)}
                  </span>
                  <Link
                    to={`/proposals/${proposal.id}`}
                    className="text-primary-500 hover:text-primary-400 text-sm font-medium transition-colors"
                  >
                    View Details →
                  </Link>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <div className="p-6 bg-dark-800/50 rounded-full w-24 h-24 mx-auto mb-6 flex items-center justify-center">
            <FileText className="h-12 w-12 text-gray-500" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No proposals found</h3>
          <p className="text-gray-400 mb-6">
            {searchTerm || filterCountry || filterLanguage 
              ? 'Try adjusting your filters to see more results'
              : 'Create your first AI-powered proposal to get started'
            }
          </p>
          <Link
            to="/create-proposal"
            className="bg-gradient-to-r from-primary-500 to-primary-600 hover:from-primary-600 hover:to-primary-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg hover:shadow-primary-500/25 inline-flex items-center"
          >
            <Plus className="h-5 w-5 mr-2" />
            Create First Proposal
          </Link>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center space-x-2">
          {[...Array(totalPages)].map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentPage(i + 1)}
              className={`px-4 py-2 rounded-lg transition-colors duration-300 ${
                currentPage === i + 1
                  ? 'bg-primary-500 text-white'
                  : 'bg-dark-800 text-gray-400 hover:bg-dark-700 hover:text-white'
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}