import { ReactNode } from 'react'
import { cn } from '../../lib/utils'

interface CardProps {
  children: ReactNode
  className?: string
  gradient?: boolean
  hover?: boolean
}

export default function Card({ children, className, gradient = false, hover = true }: CardProps) {
  return (
    <div
      className={cn(
        'rounded-xl border border-dark-700 p-6',
        gradient 
          ? 'bg-gradient-to-br from-dark-900 to-dark-800' 
          : 'bg-dark-900',
        hover && 'hover:border-primary-500/20 transition-all duration-300',
        className
      )}
    >
      {children}
    </div>
  )
}

interface CardHeaderProps {
  children: ReactNode
  className?: string
}

export function CardHeader({ children, className }: CardHeaderProps) {
  return (
    <div className={cn('mb-4', className)}>
      {children}
    </div>
  )
}

interface CardTitleProps {
  children: ReactNode
  className?: string
}

export function CardTitle({ children, className }: CardTitleProps) {
  return (
    <h3 className={cn('text-lg font-semibold text-white', className)}>
      {children}
    </h3>
  )
}

interface CardContentProps {
  children: ReactNode
  className?: string
}

export function CardContent({ children, className }: CardContentProps) {
  return (
    <div className={cn('text-gray-400', className)}>
      {children}
    </div>
  )
}