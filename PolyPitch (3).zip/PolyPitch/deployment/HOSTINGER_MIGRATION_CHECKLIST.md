# PolyPitch Hostinger Migration Checklist

## Pre-Upload Verification ✅

Your PolyPitch platform is properly packaged and ready for Hostinger migration. Here's what's included:

### Backend Package (`/deployment/backend/`)
- ✅ Complete Flask application
- ✅ All API routes (auth, proposals, calendar, expenses, stripe)
- ✅ Database models and services
- ✅ WSGI configuration for production
- ✅ Requirements file with all dependencies
- ✅ Environment template with all necessary variables
- ✅ Database initialization script

### Frontend Package (`/deployment/frontend/`)
- ✅ Complete React TypeScript application
- ✅ Modern UI components with orange/black theme
- ✅ All pages (dashboard, proposals, calendar, expenses, subscriptions)
- ✅ API integration layer
- ✅ Environment template
- ✅ .htaccess for proper routing

## Migration Steps

### 1. Domain Setup
- [ ] Point your main domain to Hostinger
- [ ] Create subdomain for API (api.yourdomain.com) or use subfolder
- [ ] Enable SSL certificate

### 2. Database Configuration
- [ ] Create PostgreSQL database in Hostinger cPanel
- [ ] Note database credentials (host, port, name, username, password)
- [ ] Test database connection

### 3. Backend Deployment
- [ ] Upload `/deployment/backend/` contents to your API location
- [ ] Rename `.env.template` to `.env`
- [ ] Configure all environment variables in `.env`
- [ ] Install Python dependencies: `pip install -r requirements.txt`
- [ ] Run database initialization: `python init_database.py`
- [ ] Configure WSGI application (point to `wsgi.py`)
- [ ] Test API endpoints: `/api/health`, `/api/auth/register`

### 4. Frontend Deployment
- [ ] Upload `/deployment/frontend/` contents to main domain public_html
- [ ] Rename `.env.template` to `.env`
- [ ] Update `VITE_API_BASE_URL` to your API domain
- [ ] Build production version if needed: `npm run build`
- [ ] Test frontend loads correctly

### 5. External Services
- [ ] Update Stripe webhook URL to your production domain
- [ ] Test Stripe payment flows
- [ ] Verify OpenAI API integration
- [ ] Test Supabase authentication

### 6. Final Testing
- [ ] User registration/login works
- [ ] AI proposal generation functions
- [ ] Calendar appointments save correctly
- [ ] Expense tracking operates properly
- [ ] Subscription payments process successfully
- [ ] All API endpoints respond correctly

## Important Configuration Notes

### Environment Variables
Ensure these are properly configured in your `.env` files:

**Backend:**
- `DATABASE_URL` - Your Hostinger PostgreSQL connection string
- `OPENAI_API_KEY` - For AI proposal generation
- `STRIPE_SECRET_KEY` - For payment processing
- `STRIPE_WEBHOOK_SECRET` - For secure webhook verification
- `SESSION_SECRET` - Strong random string for security

**Frontend:**
- `VITE_API_BASE_URL` - Your backend API URL
- `VITE_SUPABASE_URL` - Your Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Supabase anonymous key

### File Permissions
Set appropriate permissions on Hostinger:
- Backend files: 644
- WSGI file: 755
- Environment files: 600 (secure)

### CORS Configuration
Update your API CORS settings to allow your production domain.

## Troubleshooting

### Common Issues:
1. **Database Connection Errors**: Verify DATABASE_URL format and credentials
2. **API Not Loading**: Check WSGI configuration and Python path
3. **Frontend Blank Page**: Verify API_BASE_URL and build process
4. **Payment Failures**: Update Stripe webhook URL and test keys

### Support Resources:
- Hostinger Documentation
- Flask WSGI Deployment Guide
- Stripe Webhook Configuration
- PostgreSQL Connection Troubleshooting

## Success Indicators

Your migration is successful when:
- ✅ Main domain shows PolyPitch frontend
- ✅ Users can register/login
- ✅ API endpoints return proper responses
- ✅ Database operations work correctly
- ✅ Payment processing functions
- ✅ All features operate as expected

Your PolyPitch platform is production-ready for Hostinger!