# PolyPitch Hostinger Deployment Instructions

## 1. Upload Files
- Upload `backend/` folder to your domain root or subdomain
- Upload `frontend/` contents to your main domain public_html

## 2. Configure Environment Variables
- Rename `.env.template` to `.env` in both folders
- Fill in your actual API keys and database credentials

## 3. Database Setup
- Create PostgreSQL database in Hostinger cPanel
- Update DATABASE_URL in backend/.env
- Run database initialization (see README)

## 4. Python Setup
- Ensure Python 3.11+ is available
- Install dependencies: `pip install -r requirements.txt`
- Configure WSGI application pointing to wsgi.py

## 5. Domain Configuration
- Point main domain to frontend files
- Configure API subdomain or path for backend
- Update CORS settings in backend

## 6. SSL & Security
- Enable SSL certificate
- Update Stripe webhook URL to production domain
- Test all payment flows

Your PolyPitch platform will be live at your domain!
