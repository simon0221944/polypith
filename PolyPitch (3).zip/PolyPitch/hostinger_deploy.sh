#!/bin/bash

# PolyPitch Hostinger Deployment Script
# Run this script to prepare files for upload

echo "🚀 Preparing PolyPitch for Hostinger deployment..."

# Create deployment directory
mkdir -p deployment
mkdir -p deployment/backend
mkdir -p deployment/frontend

echo "📦 Copying backend files..."
# Copy backend files
cp -r api_routes deployment/backend/
cp -r services deployment/backend/
cp -r utils deployment/backend/
cp -r templates deployment/backend/
cp main.py deployment/backend/
cp models.py deployment/backend/
cp app.py deployment/backend/
cp wsgi.py deployment/backend/
cp hostinger_requirements.txt deployment/backend/requirements.txt

echo "🎨 Building frontend..."
# Build frontend
cd frontend
npm run build
cd ..

# Copy frontend build
cp -r frontend/dist/* deployment/frontend/
cp .htaccess deployment/frontend/

echo "📋 Creating environment template..."
# Create environment template
cat > deployment/backend/.env.template << EOF
# Database Configuration
DATABASE_URL=postgresql://username:password@host:port/database

# OpenAI API
OPENAI_API_KEY=your_openai_api_key

# Stripe Configuration
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_PRICE_FREE=your_free_plan_price_id
STRIPE_PRICE_BASIC=your_basic_plan_price_id
STRIPE_PRICE_PRO=your_pro_plan_price_id
STRIPE_PRICE_ENTERPRISE=your_enterprise_plan_price_id
STRIPE_WEBHOOK_SECRET=your_webhook_secret

# Session Security
SESSION_SECRET=your_session_secret_key
EOF

cat > deployment/frontend/.env.template << EOF
# Supabase Configuration
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# API Configuration
VITE_API_BASE_URL=https://yourdomain.com/api
EOF

echo "📚 Creating deployment instructions..."
cat > deployment/DEPLOY_INSTRUCTIONS.md << EOF
# PolyPitch Hostinger Deployment Instructions

## 1. Upload Files
- Upload \`backend/\` folder to your domain root or subdomain
- Upload \`frontend/\` contents to your main domain public_html

## 2. Configure Environment Variables
- Rename \`.env.template\` to \`.env\` in both folders
- Fill in your actual API keys and database credentials

## 3. Database Setup
- Create PostgreSQL database in Hostinger cPanel
- Update DATABASE_URL in backend/.env
- Run database initialization (see README)

## 4. Python Setup
- Ensure Python 3.11+ is available
- Install dependencies: \`pip install -r requirements.txt\`
- Configure WSGI application pointing to wsgi.py

## 5. Domain Configuration
- Point main domain to frontend files
- Configure API subdomain or path for backend
- Update CORS settings in backend

## 6. SSL & Security
- Enable SSL certificate
- Update Stripe webhook URL to production domain
- Test all payment flows

Your PolyPitch platform will be live at your domain!
EOF

echo "✅ Deployment package ready in ./deployment/"
echo "📁 Upload contents of deployment/frontend/ to your main domain"
echo "📁 Upload contents of deployment/backend/ to your API subdomain/folder"
echo "📖 Read deployment/DEPLOY_INSTRUCTIONS.md for detailed steps"