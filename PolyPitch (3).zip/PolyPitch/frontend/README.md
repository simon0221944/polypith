# PolyPitch Frontend

A modern React TypeScript SaaS frontend for PolyPitch - AI-powered multilingual sales proposal generator.

## Features

- **Modern Tech Stack**: React 18, TypeScript, Vite, Tailwind CSS
- **Authentication**: Supabase Auth with OAuth (Google, Facebook, Apple) + email/password
- **Multilingual**: Support for English, Spanish, and Italian
- **Responsive Design**: Mobile-first design with dark theme
- **Subscription Management**: Stripe integration for subscription billing
- **AI Proposal Generation**: Integration with backend OpenAI API

## Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Environment Setup

Copy `.env.example` to `.env` and fill in your configuration:

```bash
cp .env.example .env
```

Required environment variables:
- `VITE_SUPABASE_URL`: Your Supabase project URL
- `VITE_SUPABASE_ANON_KEY`: Your Supabase anonymous public key
- `VITE_API_BASE_URL`: Your PolyPitch backend API URL (Replit deployment)

### 3. Development Server

```bash
npm run dev
```

### 4. Build for Production

```bash
npm run build
```

## Deployment to Hostinger

### 1. Build the Project

```bash
npm run build
```

### 2. Upload to Hostinger

1. Compress the `dist` folder contents
2. Upload to your Hostinger hosting account
3. Extract in the public_html directory
4. Configure your domain to point to the uploaded files

### 3. Configure Environment Variables

Make sure your production environment variables are set correctly in the `.env` file before building.

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Navbar.tsx
│   └── ProtectedRoute.tsx
├── contexts/           # React contexts for global state
│   ├── AuthContext.tsx
│   └── LanguageContext.tsx
├── lib/               # Utilities and configurations
│   ├── api.ts         # API client for backend
│   ├── supabase.ts    # Supabase configuration
│   ├── translations.ts # Multi-language support
│   └── utils.ts       # Helper functions
├── pages/             # Page components
│   ├── HomePage.tsx
│   ├── LoginPage.tsx
│   ├── RegisterPage.tsx
│   ├── DashboardPage.tsx
│   ├── ProposalsPage.tsx
│   ├── CreateProposalPage.tsx
│   ├── PricingPage.tsx
│   └── SubscriptionPage.tsx
├── types/             # TypeScript type definitions
│   └── index.ts
├── App.tsx            # Main app component
└── main.tsx          # Entry point
```

## Authentication Flow

1. **Registration/Login**: Users can register/login with:
   - Email and password
   - Google OAuth
   - Facebook OAuth
   - Apple OAuth

2. **Session Management**: JWT tokens stored in localStorage
3. **Protected Routes**: Automatic redirect to login for authenticated pages
4. **Backend Integration**: Seamless integration with PolyPitch Flask backend

## API Integration

The frontend integrates with your PolyPitch Flask backend via REST API:

- **Authentication**: `/api/register`, `/api/login`, `/api/profile`
- **Proposals**: `/api/generate-proposal`, `/api/proposals`, `/api/proposals/:id`
- **Subscriptions**: `/stripe/create-checkout-session`, `/stripe/plans`, `/api/user/quota`

## Styling

- **Framework**: Tailwind CSS with custom dark theme
- **Color Scheme**: Orange primary (#FFA500), dark background, white/gray text
- **Components**: Custom component classes for consistency
- **Icons**: Lucide React icons
- **Responsive**: Mobile-first design approach

## Multi-language Support

Currently supports:
- English (en)
- Spanish (es)
- Italian (it)

Translation keys are stored in `src/lib/translations.ts`. To add a new language:

1. Add the language code to the `Language` type in `types/index.ts`
2. Add translations to the translations object
3. Update the language selector in `Navbar.tsx`

## State Management

- **Authentication**: Context-based with Supabase integration
- **Language**: Context-based for i18n
- **Local State**: React hooks for component-level state
- **API State**: Direct API calls with loading states

## Performance Optimizations

- **Code Splitting**: Automatic with Vite
- **Lazy Loading**: Routes and components
- **Bundle Optimization**: Tree shaking and minification
- **Image Optimization**: Responsive images and proper formats

## Browser Support

- Modern browsers (Chrome, Firefox, Safari, Edge)
- ES2020+ features
- CSS Grid and Flexbox
- Local Storage and Session Storage

## Contributing

1. Follow TypeScript best practices
2. Use Tailwind utility classes
3. Maintain consistent component structure
4. Add proper error handling
5. Update translations for new features

## Support

For issues related to the frontend application, please check:

1. Environment variables are correctly set
2. Backend API is accessible
3. Supabase project is properly configured
4. Browser console for any JavaScript errors