from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta, time
import json
from app import db
from models import Calendar, Appointment
from utils.auth_utils import token_required
from services.openai_service import suggest_optimal_scheduling
import logging

calendar_bp = Blueprint('calendar', __name__)

@calendar_bp.route('/calendar', methods=['GET'])
@token_required
def get_user_calendar(current_user):
    """Get user's calendar settings"""
    try:
        calendar = Calendar.query.filter_by(user_id=current_user.id).first()
        if not calendar:
            # Create default calendar
            calendar = Calendar(user_id=current_user.id)
            db.session.add(calendar)
            db.session.commit()
        
        return jsonify({
            'id': calendar.id,
            'name': calendar.name,
            'timezone': calendar.timezone,
            'working_hours_start': calendar.working_hours_start.strftime('%H:%M'),
            'working_hours_end': calendar.working_hours_end.strftime('%H:%M'),
            'working_days': calendar.working_days,
            'break_duration': calendar.break_duration
        })
    except Exception as e:
        logging.error(f"Get calendar error: {str(e)}")
        return jsonify({'error': 'Failed to get calendar'}), 500

@calendar_bp.route('/calendar', methods=['PUT'])
@token_required
def update_calendar(current_user):
    """Update calendar settings"""
    try:
        data = request.get_json()
        calendar = Calendar.query.filter_by(user_id=current_user.id).first()
        
        if not calendar:
            calendar = Calendar(user_id=current_user.id)
            db.session.add(calendar)
        
        if 'name' in data:
            calendar.name = data['name']
        if 'timezone' in data:
            calendar.timezone = data['timezone']
        if 'working_hours_start' in data:
            calendar.working_hours_start = datetime.strptime(data['working_hours_start'], '%H:%M').time()
        if 'working_hours_end' in data:
            calendar.working_hours_end = datetime.strptime(data['working_hours_end'], '%H:%M').time()
        if 'working_days' in data:
            calendar.working_days = data['working_days']
        if 'break_duration' in data:
            calendar.break_duration = data['break_duration']
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Calendar updated successfully'})
    except Exception as e:
        logging.error(f"Update calendar error: {str(e)}")
        return jsonify({'error': 'Failed to update calendar'}), 500

@calendar_bp.route('/appointments', methods=['GET'])
@token_required
def get_appointments(current_user):
    """Get user's appointments with optional date filtering"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 50))
        
        query = Appointment.query.filter_by(user_id=current_user.id)
        
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
            query = query.filter(Appointment.start_time >= start_dt)
        
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
            query = query.filter(Appointment.end_time <= end_dt)
        
        query = query.order_by(Appointment.start_time.asc())
        
        # Pagination
        appointments = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'appointments': [apt.to_dict() for apt in appointments.items],
            'pagination': {
                'page': page,
                'pages': appointments.pages,
                'per_page': per_page,
                'total': appointments.total
            }
        })
    except Exception as e:
        logging.error(f"Get appointments error: {str(e)}")
        return jsonify({'error': 'Failed to get appointments'}), 500

@calendar_bp.route('/appointments', methods=['POST'])
@token_required
def create_appointment(current_user):
    """Create a new appointment with conflict detection"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'start_time', 'end_time']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        start_time = datetime.fromisoformat(data['start_time'])
        end_time = datetime.fromisoformat(data['end_time'])
        
        # Validate appointment duration
        if start_time >= end_time:
            return jsonify({'error': 'End time must be after start time'}), 400
        
        # Get user's calendar
        calendar = Calendar.query.filter_by(user_id=current_user.id).first()
        if not calendar:
            calendar = Calendar(user_id=current_user.id)
            db.session.add(calendar)
            db.session.commit()
        
        # Check for conflicts
        conflicts = Appointment.query.filter_by(user_id=current_user.id).filter(
            Appointment.status != 'cancelled',
            Appointment.start_time < end_time,
            Appointment.end_time > start_time
        ).all()
        
        if conflicts:
            conflict_details = [{'id': c.id, 'title': c.title, 'start_time': c.start_time.isoformat()} for c in conflicts]
            return jsonify({
                'error': 'Appointment conflicts with existing appointments',
                'conflicts': conflict_details
            }), 409
        
        # Create appointment
        appointment = Appointment(
            user_id=current_user.id,
            calendar_id=calendar.id,
            title=data['title'],
            description=data.get('description', ''),
            start_time=start_time,
            end_time=end_time,
            location=data.get('location', ''),
            attendees=json.dumps(data.get('attendees', [])),
            reminder_minutes=data.get('reminder_minutes', 15),
            recurring=data.get('recurring', False),
            recurring_pattern=data.get('recurring_pattern'),
            recurring_end_date=datetime.fromisoformat(data['recurring_end_date']) if data.get('recurring_end_date') else None
        )
        
        db.session.add(appointment)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Appointment created successfully',
            'appointment': appointment.to_dict()
        }), 201
        
    except Exception as e:
        logging.error(f"Create appointment error: {str(e)}")
        return jsonify({'error': 'Failed to create appointment'}), 500

@calendar_bp.route('/appointments/<int:appointment_id>', methods=['GET'])
@token_required
def get_appointment(current_user, appointment_id):
    """Get specific appointment"""
    try:
        appointment = Appointment.query.filter_by(
            id=appointment_id, user_id=current_user.id
        ).first()
        
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        return jsonify(appointment.to_dict())
        
    except Exception as e:
        logging.error(f"Get appointment error: {str(e)}")
        return jsonify({'error': 'Failed to get appointment'}), 500

@calendar_bp.route('/appointments/<int:appointment_id>', methods=['PUT'])
@token_required
def update_appointment(current_user, appointment_id):
    """Update an appointment"""
    try:
        appointment = Appointment.query.filter_by(
            id=appointment_id, user_id=current_user.id
        ).first()
        
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        data = request.get_json()
        
        # Update fields
        if 'title' in data:
            appointment.title = data['title']
        if 'description' in data:
            appointment.description = data['description']
        if 'start_time' in data:
            new_start = datetime.fromisoformat(data['start_time'])
            if 'end_time' in data:
                new_end = datetime.fromisoformat(data['end_time'])
            else:
                duration = appointment.end_time - appointment.start_time
                new_end = new_start + duration
            
            # Check for conflicts (excluding current appointment)
            conflicts = Appointment.query.filter_by(user_id=current_user.id).filter(
                Appointment.id != appointment_id,
                Appointment.status != 'cancelled',
                Appointment.start_time < new_end,
                Appointment.end_time > new_start
            ).all()
            
            if conflicts:
                conflict_details = [{'id': c.id, 'title': c.title, 'start_time': c.start_time.isoformat()} for c in conflicts]
                return jsonify({
                    'error': 'Updated appointment conflicts with existing appointments',
                    'conflicts': conflict_details
                }), 409
            
            appointment.start_time = new_start
            appointment.end_time = new_end
        
        if 'end_time' in data and 'start_time' not in data:
            appointment.end_time = datetime.fromisoformat(data['end_time'])
        
        if 'location' in data:
            appointment.location = data['location']
        if 'attendees' in data:
            appointment.attendees = json.dumps(data['attendees'])
        if 'reminder_minutes' in data:
            appointment.reminder_minutes = data['reminder_minutes']
        if 'status' in data:
            appointment.status = data['status']
        
        appointment.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Appointment updated successfully',
            'appointment': appointment.to_dict()
        })
        
    except Exception as e:
        logging.error(f"Update appointment error: {str(e)}")
        return jsonify({'error': 'Failed to update appointment'}), 500

@calendar_bp.route('/appointments/<int:appointment_id>', methods=['DELETE'])
@token_required
def delete_appointment(current_user, appointment_id):
    """Delete an appointment"""
    try:
        appointment = Appointment.query.filter_by(
            id=appointment_id, user_id=current_user.id
        ).first()
        
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        db.session.delete(appointment)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Appointment deleted successfully'})
        
    except Exception as e:
        logging.error(f"Delete appointment error: {str(e)}")
        return jsonify({'error': 'Failed to delete appointment'}), 500

@calendar_bp.route('/appointments/suggest-time', methods=['POST'])
@token_required
def suggest_appointment_time(current_user):
    """AI-powered optimal time suggestion"""
    try:
        data = request.get_json()
        
        duration_minutes = data.get('duration_minutes', 60)
        preferred_date = data.get('preferred_date')
        preferences = data.get('preferences', {})
        
        # Get user's calendar and existing appointments
        calendar = Calendar.query.filter_by(user_id=current_user.id).first()
        if not calendar:
            calendar = Calendar(user_id=current_user.id)
            db.session.add(calendar)
            db.session.commit()
        
        # Get appointments for the next 7 days
        start_date = datetime.now().date()
        if preferred_date:
            start_date = datetime.fromisoformat(preferred_date).date()
        
        end_date = start_date + timedelta(days=7)
        
        appointments = Appointment.query.filter_by(user_id=current_user.id).filter(
            Appointment.status != 'cancelled',
            Appointment.start_time >= datetime.combine(start_date, time.min),
            Appointment.start_time <= datetime.combine(end_date, time.max)
        ).all()
        
        # Use AI to suggest optimal time
        suggestions = suggest_optimal_scheduling(
            calendar_settings={
                'working_hours_start': calendar.working_hours_start.strftime('%H:%M'),
                'working_hours_end': calendar.working_hours_end.strftime('%H:%M'),
                'working_days': calendar.working_days,
                'break_duration': calendar.break_duration,
                'timezone': calendar.timezone
            },
            existing_appointments=[apt.to_dict() for apt in appointments],
            duration_minutes=duration_minutes,
            preferred_date=preferred_date,
            preferences=preferences
        )
        
        return jsonify({
            'success': True,
            'suggestions': suggestions
        })
        
    except Exception as e:
        logging.error(f"Suggest appointment time error: {str(e)}")
        return jsonify({'error': 'Failed to suggest appointment time'}), 500

@calendar_bp.route('/appointments/availability', methods=['GET'])
@token_required
def check_availability(current_user):
    """Check availability for a specific date range"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date or not end_date:
            return jsonify({'error': 'start_date and end_date are required'}), 400
        
        start_dt = datetime.fromisoformat(start_date)
        end_dt = datetime.fromisoformat(end_date)
        
        # Get conflicting appointments
        conflicts = Appointment.query.filter_by(user_id=current_user.id).filter(
            Appointment.status != 'cancelled',
            Appointment.start_time < end_dt,
            Appointment.end_time > start_dt
        ).all()
        
        is_available = len(conflicts) == 0
        
        return jsonify({
            'available': is_available,
            'conflicts': [apt.to_dict() for apt in conflicts] if conflicts else []
        })
        
    except Exception as e:
        logging.error(f"Check availability error: {str(e)}")
        return jsonify({'error': 'Failed to check availability'}), 500