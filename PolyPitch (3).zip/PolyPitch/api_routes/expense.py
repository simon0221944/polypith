from flask import Blueprint, request, jsonify
from datetime import datetime, date
from sqlalchemy import func, extract
from app import db
from models import Expense, ExpenseCategory
from utils.auth_utils import token_required
from services.openai_service import categorize_expense_with_ai, analyze_expenses_with_ai
import logging

expense_bp = Blueprint('expense', __name__)

@expense_bp.route('/expenses', methods=['GET'])
@token_required
def get_expenses(current_user):
    """Get user's expenses with filtering and pagination"""
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 50))
        category = request.args.get('category')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        search = request.args.get('search')
        
        query = Expense.query.filter_by(user_id=current_user.id)
        
        # Apply filters
        if category:
            query = query.filter(Expense.category == category)
        
        if start_date:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(Expense.expense_date >= start_dt)
        
        if end_date:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(Expense.expense_date <= end_dt)
        
        if search:
            query = query.filter(
                db.or_(
                    Expense.title.ilike(f'%{search}%'),
                    Expense.description.ilike(f'%{search}%'),
                    Expense.vendor.ilike(f'%{search}%')
                )
            )
        
        query = query.order_by(Expense.expense_date.desc(), Expense.created_at.desc())
        
        # Pagination
        expenses = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'expenses': [expense.to_dict() for expense in expenses.items],
            'pagination': {
                'page': page,
                'pages': expenses.pages,
                'per_page': per_page,
                'total': expenses.total
            }
        })
        
    except Exception as e:
        logging.error(f"Get expenses error: {str(e)}")
        return jsonify({'error': 'Failed to get expenses'}), 500

@expense_bp.route('/expenses', methods=['POST'])
@token_required
def create_expense(current_user):
    """Create a new expense with AI categorization"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'amount', 'expense_date']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # AI categorization if category not provided
        category = data.get('category')
        ai_suggested_category = None
        
        if not category or data.get('use_ai_categorization', False):
            expense_description = f"{data['title']} {data.get('description', '')} {data.get('vendor', '')}"
            ai_suggestion = categorize_expense_with_ai(expense_description)
            ai_suggested_category = ai_suggestion
            if not category:
                category = ai_suggestion
        
        # Create expense
        expense = Expense(
            user_id=current_user.id,
            title=data['title'],
            description=data.get('description', ''),
            amount=float(data['amount']),
            currency=data.get('currency', 'USD'),
            category=category,
            ai_suggested_category=ai_suggested_category,
            expense_date=datetime.strptime(data['expense_date'], '%Y-%m-%d').date(),
            receipt_url=data.get('receipt_url'),
            payment_method=data.get('payment_method'),
            vendor=data.get('vendor'),
            project=data.get('project'),
            is_recurring=data.get('is_recurring', False),
            recurring_frequency=data.get('recurring_frequency'),
            tags=data.get('tags', '')
        )
        
        db.session.add(expense)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Expense created successfully',
            'expense': expense.to_dict(),
            'ai_suggested_category': ai_suggested_category
        }), 201
        
    except Exception as e:
        logging.error(f"Create expense error: {str(e)}")
        return jsonify({'error': 'Failed to create expense'}), 500

@expense_bp.route('/expenses/<int:expense_id>', methods=['GET'])
@token_required
def get_expense(current_user, expense_id):
    """Get specific expense"""
    try:
        expense = Expense.query.filter_by(
            id=expense_id, user_id=current_user.id
        ).first()
        
        if not expense:
            return jsonify({'error': 'Expense not found'}), 404
        
        return jsonify(expense.to_dict())
        
    except Exception as e:
        logging.error(f"Get expense error: {str(e)}")
        return jsonify({'error': 'Failed to get expense'}), 500

@expense_bp.route('/expenses/<int:expense_id>', methods=['PUT'])
@token_required
def update_expense(current_user, expense_id):
    """Update an expense"""
    try:
        expense = Expense.query.filter_by(
            id=expense_id, user_id=current_user.id
        ).first()
        
        if not expense:
            return jsonify({'error': 'Expense not found'}), 404
        
        data = request.get_json()
        
        # Update fields
        if 'title' in data:
            expense.title = data['title']
        if 'description' in data:
            expense.description = data['description']
        if 'amount' in data:
            expense.amount = float(data['amount'])
        if 'currency' in data:
            expense.currency = data['currency']
        if 'category' in data:
            expense.category = data['category']
        if 'expense_date' in data:
            expense.expense_date = datetime.strptime(data['expense_date'], '%Y-%m-%d').date()
        if 'receipt_url' in data:
            expense.receipt_url = data['receipt_url']
        if 'payment_method' in data:
            expense.payment_method = data['payment_method']
        if 'vendor' in data:
            expense.vendor = data['vendor']
        if 'project' in data:
            expense.project = data['project']
        if 'is_recurring' in data:
            expense.is_recurring = data['is_recurring']
        if 'recurring_frequency' in data:
            expense.recurring_frequency = data['recurring_frequency']
        if 'tags' in data:
            expense.tags = data['tags']
        
        expense.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Expense updated successfully',
            'expense': expense.to_dict()
        })
        
    except Exception as e:
        logging.error(f"Update expense error: {str(e)}")
        return jsonify({'error': 'Failed to update expense'}), 500

@expense_bp.route('/expenses/<int:expense_id>', methods=['DELETE'])
@token_required
def delete_expense(current_user, expense_id):
    """Delete an expense"""
    try:
        expense = Expense.query.filter_by(
            id=expense_id, user_id=current_user.id
        ).first()
        
        if not expense:
            return jsonify({'error': 'Expense not found'}), 404
        
        db.session.delete(expense)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Expense deleted successfully'})
        
    except Exception as e:
        logging.error(f"Delete expense error: {str(e)}")
        return jsonify({'error': 'Failed to delete expense'}), 500

@expense_bp.route('/expenses/summary', methods=['GET'])
@token_required
def get_expense_summary(current_user):
    """Get expense summary and statistics"""
    try:
        month = request.args.get('month')
        year = request.args.get('year')
        
        if not month or not year:
            now = datetime.now()
            month = now.month
            year = now.year
        else:
            month = int(month)
            year = int(year)
        
        # Total expenses for the month
        total_month = db.session.query(func.sum(Expense.amount)).filter(
            Expense.user_id == current_user.id,
            extract('month', Expense.expense_date) == month,
            extract('year', Expense.expense_date) == year
        ).scalar() or 0
        
        # Expenses by category for the month
        category_totals = db.session.query(
            Expense.category,
            func.sum(Expense.amount).label('total')
        ).filter(
            Expense.user_id == current_user.id,
            extract('month', Expense.expense_date) == month,
            extract('year', Expense.expense_date) == year
        ).group_by(Expense.category).all()
        
        # Recent expenses (last 10)
        recent_expenses = Expense.query.filter_by(user_id=current_user.id).order_by(
            Expense.expense_date.desc(), Expense.created_at.desc()
        ).limit(10).all()
        
        # Monthly trend (last 6 months)
        monthly_trend = []
        for i in range(6):
            target_date = datetime(year, month, 1) - timedelta(days=30 * i)
            monthly_total = db.session.query(func.sum(Expense.amount)).filter(
                Expense.user_id == current_user.id,
                extract('month', Expense.expense_date) == target_date.month,
                extract('year', Expense.expense_date) == target_date.year
            ).scalar() or 0
            
            monthly_trend.append({
                'month': target_date.strftime('%Y-%m'),
                'total': float(monthly_total)
            })
        
        monthly_trend.reverse()
        
        return jsonify({
            'total_month': float(total_month),
            'month': month,
            'year': year,
            'category_breakdown': [
                {'category': cat, 'total': float(total)} 
                for cat, total in category_totals
            ],
            'recent_expenses': [expense.to_dict() for expense in recent_expenses],
            'monthly_trend': monthly_trend
        })
        
    except Exception as e:
        logging.error(f"Get expense summary error: {str(e)}")
        return jsonify({'error': 'Failed to get expense summary'}), 500

@expense_bp.route('/expenses/categories', methods=['GET'])
@token_required
def get_expense_categories(current_user):
    """Get user's expense categories"""
    try:
        categories = ExpenseCategory.query.filter_by(user_id=current_user.id).all()
        
        # If no custom categories, return default categories
        if not categories:
            default_categories = [
                {'name': 'Travel', 'color': '#3B82F6', 'description': 'Transportation, accommodation, meals'},
                {'name': 'Office Supplies', 'color': '#10B981', 'description': 'Equipment, software, stationery'},
                {'name': 'Marketing', 'color': '#F59E0B', 'description': 'Advertising, promotions, events'},
                {'name': 'Software', 'color': '#8B5CF6', 'description': 'SaaS subscriptions, licenses'},
                {'name': 'Meals', 'color': '#EF4444', 'description': 'Business meals and entertainment'},
                {'name': 'Training', 'color': '#06B6D4', 'description': 'Courses, conferences, education'},
                {'name': 'Utilities', 'color': '#84CC16', 'description': 'Internet, phone, electricity'},
                {'name': 'Other', 'color': '#6B7280', 'description': 'Miscellaneous expenses'}
            ]
            return jsonify({'categories': default_categories})
        
        return jsonify({
            'categories': [category.to_dict() for category in categories]
        })
        
    except Exception as e:
        logging.error(f"Get expense categories error: {str(e)}")
        return jsonify({'error': 'Failed to get expense categories'}), 500

@expense_bp.route('/expenses/categories', methods=['POST'])
@token_required
def create_expense_category(current_user):
    """Create a new expense category"""
    try:
        data = request.get_json()
        
        if 'name' not in data:
            return jsonify({'error': 'Category name is required'}), 400
        
        category = ExpenseCategory(
            user_id=current_user.id,
            name=data['name'],
            description=data.get('description', ''),
            color=data.get('color', '#FFA500'),
            budget_limit=data.get('budget_limit')
        )
        
        db.session.add(category)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Category created successfully',
            'category': category.to_dict()
        }), 201
        
    except Exception as e:
        logging.error(f"Create expense category error: {str(e)}")
        return jsonify({'error': 'Failed to create category'}), 500

@expense_bp.route('/expenses/analyze', methods=['POST'])
@token_required
def analyze_expenses(current_user):
    """AI-powered expense analysis and optimization suggestions"""
    try:
        data = request.get_json()
        month = data.get('month', datetime.now().month)
        year = data.get('year', datetime.now().year)
        
        # Get expenses for analysis
        expenses = Expense.query.filter(
            Expense.user_id == current_user.id,
            extract('month', Expense.expense_date) == month,
            extract('year', Expense.expense_date) == year
        ).all()
        
        if not expenses:
            return jsonify({
                'success': True,
                'analysis': {
                    'summary': 'No expenses found for the selected period.',
                    'insights': [],
                    'optimization_suggestions': []
                }
            })
        
        # Prepare expense data for AI analysis
        expense_data = [expense.to_dict() for expense in expenses]
        
        # Get AI analysis
        analysis = analyze_expenses_with_ai(expense_data, month, year)
        
        return jsonify({
            'success': True,
            'analysis': analysis
        })
        
    except Exception as e:
        logging.error(f"Analyze expenses error: {str(e)}")
        return jsonify({'error': 'Failed to analyze expenses'}), 500

@expense_bp.route('/expenses/export', methods=['GET'])
@token_required
def export_expenses(current_user):
    """Export expenses as CSV data"""
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        query = Expense.query.filter_by(user_id=current_user.id)
        
        if start_date:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(Expense.expense_date >= start_dt)
        
        if end_date:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(Expense.expense_date <= end_dt)
        
        expenses = query.order_by(Expense.expense_date.desc()).all()
        
        # Format for CSV
        csv_data = []
        for expense in expenses:
            csv_data.append({
                'Date': expense.expense_date.isoformat(),
                'Title': expense.title,
                'Description': expense.description or '',
                'Amount': expense.amount,
                'Currency': expense.currency,
                'Category': expense.category,
                'Vendor': expense.vendor or '',
                'Payment Method': expense.payment_method or '',
                'Project': expense.project or '',
                'Tags': expense.tags or ''
            })
        
        return jsonify({
            'success': True,
            'data': csv_data,
            'filename': f'expenses_{start_date}_{end_date}.csv' if start_date and end_date else 'expenses.csv'
        })
        
    except Exception as e:
        logging.error(f"Export expenses error: {str(e)}")
        return jsonify({'error': 'Failed to export expenses'}), 500